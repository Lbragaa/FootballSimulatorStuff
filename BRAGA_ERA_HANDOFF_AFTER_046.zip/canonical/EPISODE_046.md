# THE BRAGA ERA — EPISÓDIO 046

2027-09-26 16:00 | São Januário | Brasileirão 2027 R25

## Vasco 3–2 Palmeiras

xG 1.34–1.47; finalizações 11–13; no alvo 7–7; posse Vasco 56%; público 19,638

## Cronologia completa
- 29' — Palmeiras: Flaco López (GOAL) — placar Vasco 0–1 Palmeiras — sem assistência
- 34' — Palmeiras: Felipe Anderson (GOAL) — placar Vasco 0–2 Palmeiras — assistência: A. Barboza
- 38' — Vasco: Facundo Colidio (GOAL) — placar Vasco 1–2 Palmeiras — assistência: Andrés Gómez
- 47' — Vasco: Paulo Henrique (YELLOW)
- 59' — Vasco: Carlos Vinícius (SUBSTITUTION) — substitui Andrés Gómez
- 65' — Palmeiras: Lucas Evangelista (SUBSTITUTION) — substitui Emiliano Martínez
- 73' — Vasco: Nuno Moreira (SUBSTITUTION) — substitui Facundo Colidio
- 75' — Vasco: Cuiabano (YELLOW)
- 78' — Palmeiras: Larson (SUBSTITUTION) — substitui Andreas Pereira
- 78' — Vasco: Carlos Vinícius (GOAL) — placar Vasco 2–2 Palmeiras — sem assistência
- 82' — Vasco: Johan Rojas (SUBSTITUTION) — substitui Bruno Duarte
- 82' — Vasco: Johan Rojas (GOAL) — placar Vasco 3–2 Palmeiras — assistência: Nuno Moreira

## O que aconteceu
- Palmeiras abre 2–0 aos 29 e 34 minutos. Colidio diminui aos 38, assistido por Gómez.
- Braga promove Carlos Vinícius aos 59 no lugar de Gómez; Carlos faz o empate aos 78.
- Johan Rojas entra por Bruno Duarte aos 82 e, no mesmo minuto, faz o terceiro após assistência de Nuno Moreira.
- O desempenho não foi defensivamente dominante: Vasco 1,34 xG, Palmeiras 1,47 xG; a eficiência ofensiva decidiu.

## Todos os jogos R25
- Vasco 3–2 Palmeiras | xG 1.34–1.47
- Mirassol 0–2 Santos | xG 1.31–1.45
- Sport 1–0 Goiás | xG 1.54–1.21
- Fluminense 4–2 São Paulo | xG 1.64–1.11
- Vitória 0–2 Flamengo | xG 1.00–1.75
- Cruzeiro 1–1 Fortaleza | xG 1.91–0.85
- Athletico-PR 3–0 Coritiba | xG 1.83–0.92
- Corinthians 2–2 Atlético-MG | xG 1.61–1.14
- Bahia 1–1 Ceará | xG 1.91–0.84
- Bragantino 1–0 Botafogo | xG 1.45–1.30

## Classificação após R25
1. Flamengo — 55 pts | 16V 7E 2D | 52 GP / 21 GC, SG +31
2. Palmeiras — 51 pts | 15V 6E 4D | 52 GP / 25 GC, SG +27
3. São Paulo — 48 pts | 15V 3E 7D | 41 GP / 32 GC, SG +9
4. Fluminense — 41 pts | 11V 8E 6D | 52 GP / 34 GC, SG +18
5. Corinthians — 40 pts | 10V 10E 5D | 41 GP / 30 GC, SG +11
6. Bahia — 40 pts | 10V 10E 5D | 33 GP / 27 GC, SG +6
7. Cruzeiro — 39 pts | 10V 9E 6D | 43 GP / 34 GC, SG +9
8. Botafogo — 38 pts | 11V 5E 9D | 35 GP / 31 GC, SG +4
9. Vasco — 38 pts | 11V 5E 9D | 36 GP / 37 GC, SG -1
10. Atlético-MG — 37 pts | 10V 7E 8D | 36 GP / 31 GC, SG +5
11. Santos — 35 pts | 9V 8E 8D | 36 GP / 29 GC, SG +7
12. Bragantino — 34 pts | 10V 4E 11D | 33 GP / 34 GC, SG -1
13. Fortaleza — 33 pts | 8V 9E 8D | 33 GP / 31 GC, SG +2
14. Ceará — 30 pts | 7V 9E 9D | 30 GP / 34 GC, SG -4
15. Athletico-PR — 25 pts | 6V 7E 12D | 35 GP / 46 GC, SG -11
16. Coritiba — 24 pts | 5V 9E 11D | 31 GP / 44 GC, SG -13
17. Vitória — 22 pts | 5V 7E 13D | 28 GP / 40 GC, SG -12
18. Mirassol — 21 pts | 6V 3E 16D | 25 GP / 42 GC, SG -17
19. Goiás — 16 pts | 4V 4E 17D | 22 GP / 51 GC, SG -29
20. Sport — 15 pts | 3V 6E 16D | 14 GP / 55 GC, SG -41

## Vasco — avaliação dos atletas
- Facundo Colidio: 73min, 1G 0A, 3 chutes, xG 0.562, nota 7.7, forma 7.121→7.306
- Andrés Gómez: 59min, 0G 1A, 4 chutes, xG 0.161, nota 7.7, forma 7.995→7.814
- Carlos Vinícius: 31min, 1G 0A, 1 chutes, xG 0.308, nota 7.6, forma 6.509→6.998
- Johan Rojas: 8min, 1G 0A, 2 chutes, xG 0.145, nota 7.5, forma 6.442→6.790
- Nuno Moreira: 17min, 0G 1A, 0 chutes, xG 0.000, nota 7.2, forma 6.539→6.771
- Léo Jardim: 90min, 0G 0A, 0 chutes, xG 0.000, nota 7.0, forma 6.869→6.911
- Alan Lescano: 90min, 0G 0A, 0 chutes, xG 0.000, nota 6.9, forma 6.917→6.824
- Paulo Henrique: 90min, 0G 0A, 0 chutes, xG 0.000, nota 6.8, forma 6.860→6.850
- Santiago Sosa: 90min, 0G 0A, 1 chutes, xG 0.164, nota 6.8, forma 6.688→6.724
- Rodrigo Villagra: 90min, 0G 0A, 0 chutes, xG 0.000, nota 6.8, forma 6.955→6.862
- Arthur Dias: 90min, 0G 0A, 0 chutes, xG 0.000, nota 6.8, forma 6.631→6.720
- Cuiabano: 90min, 0G 0A, 0 chutes, xG 0.000, nota 6.7, forma 6.588→6.624
- Carlos Cuesta: 90min, 0G 0A, 0 chutes, xG 0.000, nota 6.7, forma 6.604→6.643
- Bruno Duarte: 82min, 0G 0A, 0 chutes, xG 0.000, nota 6.7, forma 6.616→6.643

## Treinamento de defesa
- Continuidade do trabalho defensivo, registrada ANTES do jogo de R25, aplica modesta redução de 0,06 xG à projeção pré-jogo do adversário. Isso não previne gols automaticamente e não muda OVR.
- Contra o Santos (R24): 0 gols sofridos, 1,55 xGA; contra o Palmeiras (R25): 2 gols sofridos, 1,47 xGA. Amostra de dois jogos insuficiente para declarar correção defensiva completa.

## Situação
- Confiança da diretoria: 61/100
- Caixa restrito SAF: R$31,930,000.00
- Jogos oficiais de Braga registrados: 45
- Próximo Vasco: Mirassol x Vasco, 03/10/2027, R26

## Verificações
- 250/380 jogos Brasileirão 2027 concluídos, 130 agendados
- Todas as partidas anteriores permanecem idênticas, sem rerolls ou edição dos placares
- Os 96 jogos da Libertadores e os 96 da Sul-Americana continuam preservados
- Chaveamentos continentais e 48 partidas da Copa do Brasil preservados; nenhuma eliminatória nova disputada neste episódio
- Salários, orçamento e transferências não alterados
- Cartões invalidados após substituição não foram registrados neste novo jogo; súmula de gols, tiros e assistências concilia
- O resultado Vasco 3–2 Palmeiras provém de uma execução determinística única do motor; desempenho, técnicos e treinamento registrados antes da partida
