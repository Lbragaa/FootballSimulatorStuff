# Canonical Save 046
Braga Era R25, Sep 26 2027. Generated ONCE from Save045 SQLite.
250/380 matches final, 130 scheduled. KO brackets, all previous fixtures, transfer contracts, continental results and finance ledger verified unchanged. Pre-game defender chemistry only affects Palmeiras expected chance quality by -0.06 xG, not OVR or score deterministically.
