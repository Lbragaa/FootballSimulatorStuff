# CRITICAL ISSUES AND OPEN BOOKKEEPING — MUST RESOLVE TRANSPARENTLY

## Critical #1: Overdue knockout schedules at 26 September 2027
At current `meta.current_date=2027-09-26 23:30`, database records:
- `libertadores_2027_round_of_16`: **8 ties UNPLAYED**, leg1=2027-08-31 and leg2=2027-09-07, dates now passed.
- `sudamericana_2027_playoffs`: **8 ties UNPLAYED**, leg1=2027-08-26 and leg2=2027-09-02, dates now passed.
- `cdb_2027_bracket`: **4 quarterfinal ties UNPLAYED**, scheduled legs 2027-09-15 and 2027-09-22, dates now passed.
This is a genuine continuity inconsistency, NOT evidence that these games were already simulated. **Do not silently invent scores or pretend tournaments progressed.** Preferred repair, prior to advancing R26: create independent *calendar repair* checkpoint 046C, record that prior knockout dates were provisional, reschedule unfinished ties to future plausible nonconflicting slots (or user-approved deterministic retrospective catch-up without touching any prior results and honest disclosure of fitness consequences). Avoid international matches clashing with São Paulo/Flamengo/Fluminense/Bahia etc Brasil league. The rescheduling procedure is administrative and must not change any previously completed result. Mark every adjusted date in a `calendar_repair_log` or `decisions` record and validate round ordering.

## Critical #2: August 2027 wages not in ledger
`finance_ledger` includes 7 incremental payroll debits of R$1.38m for Jan–Jul only. At 26 Sep, Aug is not recorded; September due at month-end. New Sep signings Arthur Dias R$265k/month and Barreal R$160k/month plus previously tracked payroll. **Do not quietly charge R$1.38m twice; treat the true August omission as an overdue bookkeeping reconciliation to be approved and transparently logged.** Contracts have annual wage commitments distinct from monthly cash debits. Current cash R$31.93m is ledger snapshot, may be overstated relative to accrued dues. The exact payroll model for old roster beyond incremental signings is simplified. Avoid inventing untracked wages.

## Important #3: Cup objective flags not yet reconciled
`board_objectives.achieved` values are still `pending` even though Carioca semifinal reached, CDB R16 reached and Sula R16 failed. Reconcile from verified evidence and only update as an explicit state cleanup, never rewrite past fixtures.

## Important #4: Season 2026 historical coverage is partial
Database contains a 2026 R31 input snapshot and games R32–R38 + a postponed R21, plus cup semifinal/finals. It does not contain the full 380 game-by-game real 2026 table. Use the final standings `league_standings_archive` for 2026 and don't claim granular events are available for R1–R31.

## Important #5: Historical duplicated Savarino identity
`players.id=354` is active Fluminense Savarino. `players.id=196` is archived Botafogo Savarino, historical rows preserved. `player_identity_resolution` documents this. Exclude 196 from future lineups while not erasing past recorded appearances/goals.

## Important #6: Audit exact minute-order and identities before narration
A previous R24 generated yellow card for Lescano after being substituted; generator R25 tries to prevent this. Validate each later game's cards, goals, and substitutions. At R25 Johan Rojas entered and scored at minute 82; the correct event sequencing must be SUB THEN GOAL. `results046.json` has tie minute order and the narrative report has the ordered interpretation. Use player IDs, not just names, for historical attribution.

## Important #7: Avoid data drift from improvised simulation-engine string patches
Several episode scripts import parts of `engine_2027_reference.py` by text slicing and replace snippets with `.replace()` before `exec`. That is fragile. Recommend a testable `engine_v4.py` with explicit functions and explicit immutable config per round, yet ensure changes to the engine only apply to FUTURE matches. Preserve prior outcomes and seed keys. Version rules, lineup selection, substitution probabilities, training effects and possession/xG computations transparently in `match_engine_audit`.

## Important #8: Separate match reality, forecasts, and narrative
Never write Monte Carlo forecasts into official `fixtures`. Never use real current 2026 results to overwrite fictional 2027. Only a successful SINGLE stochastic/deterministic match execution can advance the canonical tables. Present matches in chronological order without advance spoilers to user.

## Important #9: External media isn't canonical
Player photos queried from the internet may be anachronistic and the underlying alternate-universe roster differs from real 2026 football. Prefer club badges/football atmosphere shots, or no images, to avoid depicting an unrelated player as a signing.
