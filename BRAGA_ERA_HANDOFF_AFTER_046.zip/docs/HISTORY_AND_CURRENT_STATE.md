# THE BRAGA ERA — HISTÓRIA COMPLETA E ESTADO CANÔNICO

Data da fotografia: **26/09/2027, após Rodada 25 do Brasileirão**. Último save: **046**. Nenhuma R26 foi disputada.
Este universo é **FICTÍCIO**: utiliza inspiração em clubes e futebolistas reais, mas 2026-27 é uma linha do tempo alternativa. Dados presentes em SQLite têm precedência sobre narrativas escritas. Alguns dados de base de 2026 foram importados de uma fotografia parcial até a R31; não alegar que o arquivo contenha 380 jogos de 2026.

## 1. Identidade e filosofia
- Manager **Luan Braga**, brasileiro, 21 anos quando contratado pelo Vasco em 23/10/2026. É o protagonista gerenciado pela IA; o usuário normalmente é o observador/diretor e gosta de torcer e discutir decisões.
- Preservar imprevisibilidade, realismo e dificuldades. Nunca rerollar uma partida para agradar ao usuário ou dar plot armor ao Vasco.
- Ao simular o jogo do Vasco, narrar **cronologicamente sem revelar resultados, vencedores, classificação final ou manchetes que causem spoiler antes do apito final**. Somente depois mostrar a rodada completa e classificação.
- O tom do jogo costuma ser PT-BR espontâneo e vibrante ("pae", "VAMO VASCO 💢"), mas com análise rigorosa e honestidade. O usuário frequentemente usa inglês; alternar naturalmente.
- Não alterar decisões do treinador por vontade do usuário a menos que este intervenha explicitamente. O usuário já autorizou ações pontuais: treinamento defensivo e aporte de R$13m para elevar o orçamento de transferências a R$20m; ambos já estão CANÔNICOS.

## 2. Temporada 2026, origem da história
- Braga assume o Vasco a partir do fim de outubro de 2026 com o campeonato parcialmente conhecido até a rodada 31. Resultados posteriores simulados.
- Vasco termina 2026 em **14º, 46 pontos, 12V 10E 16D, 46 GP 51 GC**, sobrevivendo à Série A e garantindo Sul-Americana 2027.
- Últimos jogos de 2026 sob Braga no DB: Vasco 2–0 Corinthians; Vasco 1–2 Flamengo; Athletico-PR 1–0 Vasco; Vasco 3–1 Internacional; Bragantino 1–2 Vasco; Atlético-MG 2–2 Vasco; Vasco 0–0 Vitória; Chapecoense 1–0 Vasco (jogo atrasado).
- Campanha lembrada pelo usuário: eliminação diante de Boca Juniors em São Januário por 1–3 num mata-mata anterior. Se detalhes além dessa recordação não constarem no DB, manter somente esse fato contextual, não fabricar súmula.
- Palmeiras campeão brasileiro (82), campeão da Libertadores sobre Estudiantes e campeão da Copa do Brasil sobre Atlético-MG. Atlético-MG campeão da Sul-Americana sobre Boca Juniors.
- Final de 2026: negociação fictícia da SAF Almirante Participações, 90% da SAF para investidor, 10% CRVG. Capital de 2026 e de 2027 têm destinações distintas.

## 3. Temporada 2027, até setembro
- Braga reinicia com investimento da SAF: R$100m destinados a operações de futebol em 05/01/2027; **não** significa R$100m de verba livre para jogadores. Contratações em janeiro: Gustavo Martins R$11m, Rodrigo Villagra R$14m, Carlos Vinícius R$23m.
- Campeonato Carioca: Botafogo campeão, Fluminense vice; Vasco eliminado por Fluminense na semifinal. Lescano esteve entre destaques vascaínos.
- Sul-Americana: 96/96 jogos de grupos concluídos. Vasco **3º no Grupo A com seis pontos**, eliminado após derrota ao San Lorenzo. Grupo winners avançam direto às oitavas; vice-líderes vão aos play-offs contra terceiros da Libertadores. Os play-offs existem no banco, mas NÃO foram disputados.
- Copa do Brasil 2027: Vasco supera Vila Nova na fase de 32, agregado 4–2; enfrenta Fluminense nas oitavas, vence ida no Maracanã por 2–1 (Thiago Mendes 73', Gómez 81'), mas perde volta em São Januário por 1–3 (Hulk 18', Martinelli 29', Thiago Mendes 67', Ganso 82'). Agregado Fluminense 4–3 Vasco. Quartas sorteadas: Fluminense–Cruzeiro, Fortaleza–Palmeiras, Flamengo–Botafogo, Athletico-PR–Bahia. As quartas NÃO foram jogadas.
- Libertadores 2027: 96/96 partidas de grupos simuladas e congeladas; oito confrontos de oitavas foram sorteados sem resultados: Bolívar–Palmeiras; Junior–Fluminense; O'Higgins–Vélez; Atlético-MG–River Plate; Estudiantes–Santos; Huachipato–Flamengo; The Strongest–Liverpool (URU); Atlético Nacional–Sportivo Luqueño. Ver a base oficial para ordens/mandos/datas.
- As datas provisórias de mata-matas continentais e quartas CDB ficaram no PASSADO do save 046. É um problema sério de sincronia, descrito no arquivo CRITICAL_ISSUES.md. NÃO inventar resultados ocultos, NÃO fingir que já foram jogados. Reconciliar aberta e deterministamente ANTES de avançar cronologicamente para outubro.

## 4. Mercado 2027 (todos valores e eventos ficcionais)
- Janeiro: Gustavo Martins R$11m; Rodrigo Villagra R$14m; Carlos Vinícius R$23m (subtotal R$48m).
- Agosto: SAF concede aporte EXCEPCIONAL de R$13m ao orçamento de taxas de aquisição, elevando a autorização anual de R$55m para R$68m; verba disponível na janela sobe de R$7m para R$20m. Não retirar da reserva emergencial.
- Setembro: Vasco compra Arthur Dias, zagueiro 75 OVR do Athletico-PR, R$13,2m, R$265k/mês; Álvaro Barreal, meia 73 OVR do Santos, R$5,4m, R$160k/mês. Total gasto R$66,6m, **R$1,4m de limite de aquisição sobrando**. Outras transações entre clubes: Maurício Palmeiras→Ceará, Erick Pulgar Flamengo→Grêmio, Walace Vitória→Coritiba, Tomás Pérez Atlético-MG→Goiás. Conferir tabelas `transfers`,`transfer_contracts`,`market_negotiations_2027`.
- Salários incrementais: R$22m anuais autorizados, R$21,66m comprometidos, R$0,34m de headroom. Agentes/scouting R$7m, R$4,81m comprometidos, R$2,19m restantes. Reserva emergencial R$16m intocada.
- Conta restrita de futebol em 26/09: **R$31,93 milhões**. São dinheiro contabilizado, não verba liberada para novas contratações. Não contabilizar a mesma aquisição ou folha duas vezes. Foi registrada folha mensal de jan-jul 2027, mas **não** há lançamentos de agosto e setembro até este save (pendência de reconciliação).

## 5. Tática e evolução recente
- Base do Braga: 4-2-3-1 assimétrico, linha média 4-4-2 sem bola, um lateral sobe por vez, Sosa/Villagra no duplo pivô, Lescano na criação, Colidio pela esquerda, Gómez pela direita, Bruno Duarte no comando. Suplentes relevantes: Carlos Vinícius (inclusive dupla com Bruno), Nuno Moreira, Thiago Mendes, Johan Rojas, Barreal, Cauan Barros, Brenner.
- Dificuldade crônica de 2027: Vasco frequentemente sofre o primeiro gol, concede transições e perde vantagens, eliminando-se de duas copas após oscilações defensivas.
- O usuário exigiu trabalho intenso de defesa e ENTROSAMENTO. Microciclo 13–18/09: compactação, bolas paradas, comunicação e recuperação; aplicado de modo tímido e mensurável contra Santos (clean sheet, mas 1,55 xGA). Semana 20–25/09: continuidade e redução fixada antes do jogo de **0,06 xG das chances de Palmeiras**, sem aumento permanente de OVR e sem garantir resultado. Efeito já foi usado em R25 e NÃO deve ser cobrado de novo retroativamente.
- Gómez atravessa excelente fase de gols. Bruno Duarte tem números fortes na temporada e segue importante mesmo quando não marca. Carlos Vinícius vinha recebendo poucos minutos: entrou contra Palmeiras e marcou. Química/form individual é dinâmica; usar perfil `match_form_profile` e `player_form_snapshot`.

## 6. Último jogo REALMENTE SIMULADO: 26/09/2027, R25
**VASCO 3–2 PALMEIRAS, virada em São Januário de 0–2!** O arquivo `canonical/EPISODE_046.md` narra todos os fatos e o JSON contém a súmula completa. Nenhuma partida foi perdida; o save 046 EXISTE.
- 29' Flaco López 0–1 (Palmeiras).
- 34' Felipe Anderson 0–2 (Palmeiras; assistência A. Barboza registrada).
- 38' Facundo Colidio 1–2 (assistência Andrés Gómez).
- 59' Carlos Vinícius entra por Andrés Gómez.
- 73' Nuno Moreira entra por Colidio.
- 78' Carlos Vinícius 2–2 (sem assistência).
- 82' Johan Rojas entra por Bruno Duarte e marca o 3–2 no MESMO minuto, assistência Nuno Moreira.
- xG Vasco 1,34 Palmeiras 1,47; finalizações 11–13; chutes no alvo 7–7; posse Vasco 56%; público 19.638. Vitória notável pela eficiência, não domínio defensivo. A defesa sofreu dois gols e a melhoria deve continuar.
- Classificação Vasco após R25: **9º, 38 pts, 25 jogos, 11V 5E 9D, 36 gols feitos, 37 sofridos, saldo −1**. Flamengo líder 55, Palmeiras 51, São Paulo 48.
- Diretoria subiu confiança para **61/100**; manager acumula 45 partidas no marcador `braga_matches`.
- **PRÓXIMO: Mirassol x Vasco, 03/10/2027, Brasileirão R26.** Ainda não jogado.

## 7. Dez jogos COMPLETOS da R25
- Vasco 3–2 Palmeiras
- Mirassol 0–2 Santos
- Sport 1–0 Goiás
- Fluminense 4–2 São Paulo
- Vitória 0–2 Flamengo
- Cruzeiro 1–1 Fortaleza
- Athletico-PR 3–0 Coritiba
- Corinthians 2–2 Atlético-MG
- Bahia 1–1 Ceará
- Bragantino 1–0 Botafogo

## 8. Classificação completa após 25 rodadas
| # | Clube | Pts | V–E–D | GP–GC | SG |
|---:|---|---:|---:|---|---:|
| 1 | Flamengo | 55 | 16–7–2 | 52–21 | +31 |
| 2 | Palmeiras | 51 | 15–6–4 | 52–25 | +27 |
| 3 | São Paulo | 48 | 15–3–7 | 41–32 | +9 |
| 4 | Fluminense | 41 | 11–8–6 | 52–34 | +18 |
| 5 | Corinthians | 40 | 10–10–5 | 41–30 | +11 |
| 6 | Bahia | 40 | 10–10–5 | 33–27 | +6 |
| 7 | Cruzeiro | 39 | 10–9–6 | 43–34 | +9 |
| 8 | Botafogo | 38 | 11–5–9 | 35–31 | +4 |
| 9 | Vasco | 38 | 11–5–9 | 36–37 | -1 |
| 10 | Atlético-MG | 37 | 10–7–8 | 36–31 | +5 |
| 11 | Santos | 35 | 9–8–8 | 36–29 | +7 |
| 12 | Bragantino | 34 | 10–4–11 | 33–34 | -1 |
| 13 | Fortaleza | 33 | 8–9–8 | 33–31 | +2 |
| 14 | Ceará | 30 | 7–9–9 | 30–34 | -4 |
| 15 | Athletico-PR | 25 | 6–7–12 | 35–46 | -11 |
| 16 | Coritiba | 24 | 5–9–11 | 31–44 | -13 |
| 17 | Vitória | 22 | 5–7–13 | 28–40 | -12 |
| 18 | Mirassol | 21 | 6–3–16 | 25–42 | -17 |
| 19 | Goiás | 16 | 4–4–17 | 22–51 | -29 |
| 20 | Sport | 15 | 3–6–16 | 14–55 | -41 |

## 9. Destaques do Vasco no BRASILEIRÃO 2027 (não misturar com estatísticas de todas as competições)
| Jogador | Jogos | Gols | Assistências | xG |
|---|---:|---:|---:|---:|
| Bruno Duarte | 25 | 10 | 0 | 6.57 |
| Andrés Gómez | 25 | 7 | 4 | 7.16 |
| Alan Lescano | 25 | 5 | 4 | 2.69 |
| Facundo Colidio | 23 | 5 | 0 | 6.5 |
| Nuno Moreira | 12 | 3 | 1 | 1.85 |
| Johan Rojas | 10 | 2 | 1 | 0.91 |
| Carlos Vinícius | 18 | 2 | 1 | 2.08 |
| Brenner | 11 | 2 | 0 | 1.19 |
| Rodrigo Villagra | 25 | 0 | 4 | 3.43 |
| Cuiabano | 19 | 0 | 3 | 0.0 |
| Santiago Sosa | 25 | 0 | 3 | 2.57 |
| Paulo Henrique | 25 | 0 | 2 | 1.17 |
| Alan Saldivia | 15 | 0 | 1 | 0.27 |
| Robert Renan | 23 | 0 | 1 | 0.0 |
| Thiago Mendes | 11 | 0 | 1 | 0.23 |

`players.goals/apps` são acumulados pessoais e podem incluir outras competições/anos; para estatísticas por competição e ano usar `player_season_totals` + `player_matches`, com cuidado especial para CDB (`cdb_2027_player_performance`) e continental.

## 10. Cronologia do Vasco no Brasileirão 2027 (25 jogos)
| Rodada | Data | Resultado |
|---|---|---|
| R03 | DATE UNKNO | Vasco 1–2 São Paulo |
| R04 | DATE UNKNO | Sport 1–1 Vasco |
| R05 | DATE UNKNO | Vasco 0–3 Santos |
| R01 | 2027-03-13 | Vasco 1–1 Fortaleza |
| R02 | 2027-03-20 | Vitória 0–2 Vasco |
| R06 | 2027-04-17 | Palmeiras 4–1 Vasco |
| R07 | 2027-04-24 | Vasco 2–1 Mirassol |
| R08 | 2027-05-01 | Goiás 3–2 Vasco |
| R09 | 2027-05-08 | Vasco 2–1 Fluminense |
| R10 | 2027-05-15 | Flamengo 1–0 Vasco |
| R11 | 2027-05-22 | Vasco 2–1 Cruzeiro |
| R12 | 2027-05-29 | Coritiba 0–2 Vasco |
| R13 | 2027-06-05 | Vasco 1–1 Corinthians |
| R14 | 2027-06-12 | Ceará 3–1 Vasco |
| R15 | 2027-06-20 | Vasco 2–1 Bragantino |
| R16 | 2027-06-26 | Botafogo 3–0 Vasco |
| R17 | 2027-08-02 | Vasco 1–2 Bahia |
| R18 | 2027-08-08 | Atlético-MG 1–2 Vasco |
| R19 | 2027-08-15 | Vasco 2–1 Athletico-PR |
| R20 | 2027-08-22 | Fortaleza 1–1 Vasco |
| R21 | 2027-08-29 | Vasco 3–1 Vitória |
| R22 | 2027-09-05 | São Paulo 2–1 Vasco |
| R23 | 2027-09-12 | Vasco 1–1 Sport |
| R24 | 2027-09-19 | Santos 0–2 Vasco |
| R25 | 2027-09-26 | Vasco 3–2 Palmeiras |

## 11. Objetivos e projeções
- Brasileirão 2027: meta de diretoria **top 12**, evitar briga contra rebaixamento. Apesar das copas frustrantes, o torcedor vê valor na evolução e quer mirar uma posição continental.
- Usuário aprecia forecasts Monte Carlo, mas estes são probabilidades-modelo e NÃO resultados canônicos. A rodada anterior previa cerca de 54,5 pontos finais com base em dados até R24. **Como Vasco venceu Palmeiras na R25, aquela previsão ficou defasada!** Recalcular a partir de R25 antes de afirmar odds novas.
- Financeiramente o usuário vê futuro brilhante com SAF; novos aportes futuros não devem ser automaticamente reconhecidos antes dos vencimentos e aprovações.
- Apoiar o otimismo justificado sem falsa garantia. O treinamento e a química devem gerar efeitos leves e auditáveis ao longo do tempo. O calendário seguinte tem Mirassol (R26), Goiás (R27), Fluminense (R28), Flamengo (R29), Cruzeiro (R30), Coritiba (R31): cada jogo precisa manter risco próprio.
