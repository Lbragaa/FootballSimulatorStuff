# START HERE — THE BRAGA ERA, HANDOFF AFTER SAVE 046

## Important discovery
The previously 'lost' Vasco vs Palmeiras match has been **fully recovered**, not re-simulated: Vasco 3–2 Palmeiras (26 September 2027, Brazilian Série A R25), after trailing 0–2. All ten round-25 games are saved and audited. Canonical Save 046 exists, with full database and results. Next Vasco fixture: Mirassol vs Vasco on 3 October 2027, R26. Do not re-run R25.

## How to use in a NEW ChatGPT chat
1. **Download this entire handoff ZIP onto your device** and keep it somewhere you control. Sandbox file references in this old chat should NOT be assumed to work in a new chat.
2. Start a **new** ChatGPT conversation; **attach the ZIP as a file**, not just a copied link. If the UI or file-size rules reject the ZIP, upload `canonical/braga_save.sqlite`, `docs/MASTER_PROMPT_COPY_INTO_NEW_CHAT.md`, `docs/HISTORY_AND_CURRENT_STATE.md`, `docs/CRITICAL_ISSUES.md`, and `canonical/results046.json` separately. The original Save046 ZIP is another valid alternative for the database.
3. Copy/paste the FULL content of `docs/MASTER_PROMPT_COPY_INTO_NEW_CHAT.md` as your first text message. You can add: "Load the attachment, validate the checkpoint, and do not play a match until I say so."
4. Ask the new ChatGPT to run the bundled validator (`tools/verify_handoff.py`), inspect DB, confirm R25 (Vasco 3–2 Palmeiras), and address **overdue knockout dates and unbooked August payroll** before R26.
5. Thereafter, say "Go to Mirassol x Vasco, Round 26 — simulate all ten and narrate chronologically without spoilers." Attach the newly produced Save each time you change to another chat.

## Contents
- `canonical/braga_save.sqlite` = full official database; 2026 historical snapshot + 2027 results, all 65 SQL tables including SQLite internal table.
- `canonical/Braga_Era_SAVE_046_ORIGINAL.zip` = the original ~13MB official Save046 ZIP, including Save045 and preceding ZIP backup chain. Not merely a summary.
- `canonical/results046.json` = exact R25 game data; `EPISODE_046.md` = chronological historical report.
- `canonical/braga_player_database_046.xlsx` = last full player/league workbook, available for spreadsheet software.
- `docs/MASTER_PROMPT_COPY_INTO_NEW_CHAT.md` = full-length reusable instructions.
- `docs/HISTORY_AND_CURRENT_STATE.md` = 2026–2027 historical chronology, complete R25 classification, 25 Vasco league games, roster stats, economics.
- `docs/TECHNICAL_AND_ENGINE_MANUAL.md` = SQL structure and reliable process for running and testing next simulations.
- `docs/CRITICAL_ISSUES.md` = overdue cups, payroll, archive identity and other unresolved risks; never hide them.
- `exports/` = all DB table backup JSON.gz plus convenient CSV snapshots.
- `reference/` = the actual reference match engine, recent episode scripts, old audit/market/training reports.
- `tools/verify_handoff.py` = standalone verification tool using standard Python.
- `MANIFEST_SHA256.txt` = cryptographic SHA256 of each included file (excluding itself).

## Recommended continuation procedure
Create optional **Save046C (calendar & finance audit)** explicitly from Save046 before Oct3, then **Save047 (R26)**; the admin checkpoint must not alter any prior scores. User's requested experience: in-depth live chronological match narration without spoilers and honest full-league developments, periodic projections, finance and transfers with auditability.

## Current canonical numbers
Saved 2027-09-26 23:30; 250 completed Brasileiro 2027 fixtures, 130 scheduled; Vasco 9th, 38 pts, 11W 5D 9L, GF36 GA37; board confidence 61; manager 45 recorded games; owner-restricted account R$31.93m (overdue monthly payroll risk). Vasco's R25 3–2 Palmeiras is FINAL. Training benefits limited and already applied to this match.
