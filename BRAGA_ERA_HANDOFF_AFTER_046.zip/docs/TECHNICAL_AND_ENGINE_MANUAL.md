# TECHNICAL OPERATIONS MANUAL — REPRODUCIBLE FOOTBALL SIM

## The database is the source of truth
- Single file: `canonical/braga_save.sqlite`. SQLite native, no external service needed. Read with Python `sqlite3`.
- `canonical/Braga_Era_SAVE_046_ORIGINAL.zip` is the original 2027-09-26 official save zip. It contains the preceding Save 045 backup and code; the chain is nested. Keep intact.
- `exports/all_tables_046.json.gz` contains a complete second JSON-format snapshot of all user tables. Exported CSVs give human-readable views. `canonical/results046.json` is the exact last round's structured result, including goals, subs, XI, standings, board, next date.
- All timestamps in simulation are **in fictional 2027 local event time**, not today's real-world October 2026 timestamp.

## SQL model and key tables
- `meta(key,value)`: version, date, next match, confidence, money-related notes, history flags, manager count. `saved_state_version=046`.
- `clubs`: 2027 Série A running standings and team model strengths. `league_participants`: exactly 20 2027 teams.
- `fixtures`: 2026 legacy and 2027 Brasil results (`competition='Brasileirão 2027'`, `round='R26'` etc), 380 scheduled total for season 2027; 250 final, 130 scheduled. `events`, `shots`, `player_matches` refer to `fixtures.id`.
- `players`: 547 footballers, integer `id`, club membership, form/ovr/fitness/morale, cumulative goals/apps, some inactive/archive identity cases. `player_season_totals` by year and competition; `match_form_profile` rolling form; `player_form_snapshot` history.
- `cdb_2027_bracket`, `cdb_2027_legs`, `cdb_2027_events`, `cdb_2027_shots`, `cdb_2027_player_performance`: separate 2027 Copa do Brasil engine, not standard fixtures. 16 R32 ties + 8 R16 ties have both legs (48 games). Quarterfinals unplayed with overdue provisional dates.
- `libertadores_2027_*`: 32 teams, 96 group fixtures, standings, completed; eight R16 pairings scheduled unplayed.
- `sudamericana_2027_*`: 32 teams, 96 group fixtures, standings, completed; eight playoff ties scheduled unplayed.
- `finance_budget`,`finance_ledger`,`finance_assumptions`,`transfers`,`transfer_contracts`,`board_capital_decisions`,`ownership_events`: only recognized approval sources; do not recalculate money casually.
- `decisions`,`training_microcycles_2027`,`tactical_match_log`,`match_engine_audit`,`player_postmatch_impact`,`news`: model decisions and storyline.
- `league_standings_archive`,`competition_history`,`world_finals`,`cup_summary`: 2026 history.

## Canonical R25 inventory
- Brasileiro: R1–R25 ALL 10 matches each final = 250/380; R26–R38 scheduled = 130. R26 next 2027-10-03 **Mirassol HOME vs Vasco AWAY**.
- 2027 Libertadores: 96 completed group fixtures; R16 unplayed.
- 2027 Sul-Americana: 96 completed group fixtures; playoffs unplayed.
- 2027 Copa do Brasil: R32 and R16 both legs done, QF/SF/final unplayed.
- 2027 Brazilian roster 20 teams; 547 total player records (also archived clubs). Player identity Savarino as described.
- 2026 season: final standings archive 20 entries; limited recorded historical matches.

## One-match / one-round procedure — model-first, NO SPOILERS
1. Choose most recent canonical SAVE and **make copy**, not overwrite prior. Read `meta` and identify next fixture from `fixtures`.
2. If missing overdue competition deadlines, reconcile admin calendar before gameplay. For this handoff see CRITICAL_ISSUES.md.
3. Confirm exactly 10 scheduled R26 games and 20 unique clubs. Pull every team roster and available player fitness.
4. Set tactical/training/calibration rules and deterministic seed BEFORE simulating. Do not use random search for a desired outcome; no post-result tuning.
5. User is not selecting a lineup by default. Braga autonomously chooses a plausible XI influenced by OVR, rolling form, fitness, injuries, tactical fit, and continuity. New signings do not automatically start. No injured/ineligible players or historically archived IDs.
6. Simulate each of the ten league games exactly once, using established engine rules and deterministic fixture seed. Engine baseline in `reference/engine_2027_reference.py`, and most up-to-date episode changes are in `reference/run046.py`. The current engine uses per-shot xG/probabilities, Poisson-inspired chance generation, possession, game state, manager choices, live substitutions, home advantage, form and morale. Follow actual code, not this abstract summary.
7. After a round, update `fixtures`, `events`,`shots`,`player_matches`,`player_season_totals`,`players` form/fitness/morale as engine defines; update all 20 clubs' W/D/L, points, GF/GA and expected metrics. Record `match_engine_audit`, `decisions`, training if applied.
8. Before COMMIT/packaging, verify: each fixture one result; 22 starters; goals match scored shot rows, goal events and player sums; sums of on-target/shot/xG match fixture totals; cards occurred while player eligible/on field; injuries logged; standings recomputed from EVERY final league fixture and compared with `clubs`; 250 previous fixtures unchanged byte-for-byte; foreign cups untouched unless playing them; finance ledger and transfers unchanged unless authorized chronological events were processed.
9. Commit to a NEW SQLite path, update `meta.saved_state_version`, `current_date`, `next_match_fixture`, next league status. Export `resultsNNN.json`, episode report, spreadsheets, code reproducibility and backup parent ZIP. Maintain a ledger of upstream file SHA256 and output checksum.
10. Narration to user: provide match preview and coach choices, then **chronological story**: kickoff, first half, interval, second half, stoppage time, whistle. Only AFTER whistle: final score card, xG/shots/player ratings, all nine other round scores, new table, fitness/finance, objective analysis, links to verified files and next match option. If the user asks for a shorter recap, adapt length but never spoil prematurely.

## Important implementation details
- Prior scripts use `rng_for('braga2027', fixture_id)`. Read `reference/engine_2027_reference.py` for exact definition. Deterministic same seed is for reproducibility, NOT authorization to rerun already settled games.
- Recent player form boost is applied through `match_form_profile` in episode scripts, and snapshots follow match updates. Do not inflate base OVR as a reward for a win.
- Defense training: R24 completed transient strength effect, R25 `-0.06 xG` to opponent prematch expected quality. It is small and NOT a guaranteed clean sheet. Track five-match rolling xGA, 0–20' goals, early-conceded percentage, clean sheets, leads thrown away, and fitness cost. Tune ONLY future rounds and precommit.
- Injury/fitness recovery is staged before round, not invented after observing outcome.
- Transfers 2027 already allocated; no unapproved new cash injection or player-sale recycling without a completed deal.
- August/September payroll ledger issue is OPEN, see CRITICAL_ISSUES.md.

## High-value upgrades for the next assistant
1. Stabilize engine as Python package with `SeasonState`, `MatchEngine`, `Calendar`, `Competition`, `Finance`, `Audit` modules; stop source-string `.replace()/exec()` when practical. Upgrade forward only.
2. Make separate **two ledgers**: immutable game log/event sourcing (`event_id`,`phase`,`before`,`after`,`seed`,`checksum`) and materialized tables (`clubs`, player stats) recomputed from events. Makes save corruption and rewrites easier to detect.
3. Create `calendar_events` with status `planned/rescheduled/played`, per-competition blackout dates and max rest/travel heuristics. Catch past-due unplayed knockout ties automatically.
4. Make `tactical_chemistry` a bounded, slowly-changing, auditable attribute by unit (GK+CB, FB+CB, DM+CB, attacking trios) with gains from training AND shared minutes; modest effects on errors/xGA/xG creation, plateaus and fades with new teammates. Separate defensive **process** from clean sheet outcomes.
5. Improve substitutions: minute and ordering exact; substitutions can share a minute with goals only if player entered first. Track bench/started minutes cleanly.
6. Keep two team-strength measures: base-quality prior and rolling-current-form measure; implement projections using both, with calibrated uncertainty and actual remaining opponents/home advantages. No spurious >90% certainty on G4 if model is not calibrated.
7. Handle cup competitions similarly, ensuring authentic aggregate rules, no away goals if not in rules, penalties when tied, and qualification dependencies. Preserve Cup QF vs continental schedules.
8. Give realistic season finance: recognized capital, restricted approvals, signed wage obligations, monthly cash expense, sponsorship/attendance uncertain; never double count wages or release future SAF tranches prematurely.
9. Generate automated unit/integration test artifact and nonspoiling pregame outline; all critical data exported in one master zip.
10. For 2026 historical games not in DB, show limitation, don't fake complete snapshots.

## Quick verification shell
```
python tools/verify_handoff.py
```
Run from the handoff folder; or `python /path/to/handoff/tools/verify_handoff.py`. Uses only standard Python.

## Future user interaction suggestions (no direct need to ask the user)
- If next user message is simply "next game", first create 046C calendar reconciliation checkpoint transparently (administrative only), then simulate R26 (if enough budget/time), mention calendar correction after the match, or ask consent only if the repair would change settled results.
- If next user asks for recap of R25, `canonical/EPISODE_046.md` already exists; narrate that real result, do not reroll.
