from pathlib import Path
import json,sqlite3
from artifact_tool import Workbook,SpreadsheetFile
B=Path('/mnt/data/Braga_Era');O=B/'work037L';v=json.loads((O/'libertadores_2027_results.json').read_text());c=sqlite3.connect(O/'braga_save.sqlite');c.row_factory=sqlite3.Row
wb=Workbook.create();NAVY='#1B3046';GOLD='#BE983F';SAGE='#147668'
def add(name,headers,rows,widths=None):
 s=wb.worksheets.add(name)
 matrix=[list(headers)]+[list(r) for r in rows]
 if len(matrix)==1:matrix.append([None]*len(headers))
 s.get_range_by_indexes(0,0,len(matrix),len(headers)).values=matrix
 s.get_range_by_indexes(0,0,1,len(headers)).format={'fill':NAVY,'font':{'bold':True,'color':'#FFFFFF'},'row_height':28}
 s.get_range_by_indexes(1,0,len(matrix)-1,len(headers)).format.row_height=20
 for i,w in enumerate(widths or [20]*len(headers)):
  s.get_range_by_indexes(0,i,len(matrix),1).format.column_width=w
 s.freeze_panes.freeze_rows(1)
 return s
add('Overview',['Metric','Value'],[
 ('Edition','Libertadores 2027 — The Braga Era (fictional)'),('Checkpoint','037L, based on Save 037'),('In-universe cutoff','2027-08-12'),('Group stage matches',96),('Teams',32),('Groups',8),('Games per team',6),('Round-of-16 pairings',8),('Sula playoffs linked',8),('Brazil qualifiers carried from 2026',9),('Historical Brasileirao completed and preserved',180),('Historical Sula completed and preserved',96),('Cup of Brazil fifth phase completed and preserved',32),('Manager next match','2027-08-15 Vasco vs Athletico-PR'),('Finance, rating, fitness, squad modifications',0),('Match engine','Seeded team-strength + home advantage + Bolivia altitude; Poisson goals'),('Dates warning','Historical group dates retrospective, KO dates provisional'),('Special draw','Exactly one double-Brazil group because 9 Brazilian qualifiers / 8 groups')],[52,106])
add('Participants',['Pot','Club','Country','Strength','Route','Established prior qualification'],[(p['pot'],p['club'],p['country'],p['strength'],p['route'],'yes' if p['canonical'] else 'fictional pool') for p in sorted(v['teams'],key=lambda p:(p['pot'],p['club']))],[9,30,13,13,48,29])
add('Group tables',['Group','Rank','Club','P','W','D','L','GF','GA','GD','Pts','Advance'],[(r['group'],r['rank'],r['club'],r['gp'],r['w'],r['d'],r['l'],r['gf'],r['ga'],r['gd'],r['pts'],r['route']) for r in v['outcomes']],[9,9,32,9,9,9,9,10,10,10,10,20])
add('All 96 matches',['Group','MD','Date','Home','GH','GA','Away','xG H','xG A','Shots H','Shots A','SOT H','SOT A','Seed'],[(r['group'],r['md'],r['dated'],r['home'],r['hg'],r['ag'],r['away'],r['hxg'],r['axg'],r['hs'],r['ats'],r['hot'],r['aot'],r['seed']) for r in sorted(v['matches'],key=lambda r:(r['md'],r['group'],r['home']))],[10,8,18,30,9,9,32,12,12,12,12,11,11,23])
add('Round of 16',['Tie','Leg1 home (runner)','Leg2 home (winner)','Runner group','Winner group','Leg1 provisional','Leg2 provisional','Status'],[(x['tie'],x['home1'],x['home2'],x['runner_group'],x['winner_group'],x['dates'][0],x['dates'][1],x['status']) for x in v['r16']],[17,32,32,16,16,20,20,17])
add('Sula Playoffs',['Tie','Libertadores 3rd (home first)','Sula runner (home return)','Lib group','Sula group','Leg1 provisional','Leg2 provisional','Status'],[(x['tie'],x['lib'],x['sula'],x['lib_group'],x['sula_group'],'2027-08-26','2027-09-02',x['status']) for x in v['sula_playoffs']],[17,36,34,15,15,21,21,17])
add('Brazil campaigns',['Club','Group','Rank','Points','Goal difference','Group W-D-L','Route'],[(r['club'],r['group'],r['rank'],r['pts'],r['gd'],f"{r['w']}-{r['d']}-{r['l']}",r['route']) for r in sorted(v['outcomes'],key=lambda r:(r['rank'],r['group'])) if next(t for t in v['teams'] if t['club']==r['club'])['country']=='BRA'],[28,9,9,13,19,18,23])
add('Audit and assumptions',['Check','Result','Details'],[
 ('Original clubs/players/fixtures','PASS','Checked table-by-table against Save037, rows unchanged.'),('Original Sula fixtures and outcomes','PASS','96 completed matches unchanged.'),('Original Copa do Brasil games','PASS','32 completed R32 legs unchanged.'),('Original finance ledger','PASS','July 31 payroll already paid in Save037, unchanged.'),('Original Vasco current form and ratings','PASS','No historical fitness/form/rating rewrites.'),('Libertadores fixtures','PASS','96 games, one home/one away per opponent, six per club.'),('Standings sum','PASS','All goals/points/fixtures match fixture-level results.'),('Libertadores participants','PASS','Nine original Brazilian qualifiers, no Sula group participants.'),('Same-country group conflict','EXCEPTION','Group B contains Atlético-MG and Bragantino: nine Brazilian entrants require one double Brazil group.'),('R16','PASS','16 qualified, eight ties, no matches simulated; same-group repeat pairs are allowed.'),('Sula playoff links','PASS','8 best Libertadores thirds vs 8 existing Sula runners-up, no playoff games simulated.'),('Player rosters for foreign clubs','LIMITATION','Only Brazilian 2027 Serie A player database present; foreign teams team-level ratings and results.'),('Date alignment','PROVISIONAL','Backfilled Apr-May group stage; knockout dates provisional pending three-competition calendar review.'),('Source basis','REAL RULE REFERENCE','https://gol.conmebol.com/libertadores/en/news/sorteo-de-la-fase-de-grupos-de-la-conmebol-libertadores-2026-fecha-horario-clasificados')],[43,23,108])
out=O/'libertadores_2027_database_037L.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(out))
print('Saved',out,out.stat().st_size)
print(wb.inspect({'kind':'table','range':'Group tables!A1:L8','include':'values','table_max_rows':8,'table_max_cols':12}).ndjson[:2800])
c.close()
