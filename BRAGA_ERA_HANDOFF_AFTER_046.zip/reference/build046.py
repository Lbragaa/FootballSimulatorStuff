"""Build Save046 report, sheet, and reproducible archive from single locked result."""
from pathlib import Path
import json, sqlite3, zipfile, hashlib
from artifact_tool import Workbook,SpreadsheetFile
B=Path('/mnt/data/Braga_Era');P=B/'work046';d=json.loads((P/'results046.json').read_text());v=d['vasco']
c=sqlite3.connect(P/'braga_save.sqlite');c.row_factory=sqlite3.Row
club=lambda pid: c.execute('select name from players where id=?',(int(pid),)).fetchone()[0]
ve=[dict(r) for r in c.execute('''select e.minute,p.name player,e.event_type type,cl.name club,e.notes,e.xg from events e join players p on p.id=e.player_id join clubs cl on cl.id=e.club_id where e.fixture_id=? order by e.minute,e.id''',(v['id'],))]
for e in ve:
 if e['notes'].startswith('assist:'):e['assist']=club(e['notes'].split(':')[1])
 if e['notes'].startswith('out:'):e['out']=club(e['notes'].split(':')[1])
# xG presentation and persisted reports
lines=['# THE BRAGA ERA — EPISÓDIO 046','', '2027-09-26 16:00 | São Januário | Brasileirão 2027 R25','',f"## Vasco {v['hg']}–{v['ag']} Palmeiras",'',f"xG {v['hxg']:.2f}–{v['axg']:.2f}; finalizações {v['hs']}–{v['as']}; no alvo {v['hst']}–{v['ast']}; posse Vasco {v['possession_h']}%; público {v['att']:,}",'','## Cronologia completa']
score={'Vasco':0,'Palmeiras':0}
for e in ve:
 s=f"{e['minute']}' — {e['club']}: {e['player']} ({e['type']})"
 if e['type']=='GOAL':
  score[e['club']]+=1;s+=f" — placar Vasco {score['Vasco']}–{score['Palmeiras']} Palmeiras";s+=f" — assistência: {e['assist']}" if e.get('assist') else ' — sem assistência'
 elif e['type']=='SUBSTITUTION':s+=f" — substitui {e.get('out','?')}"
 lines.append('- '+s)
lines+=['','## O que aconteceu','- Palmeiras abre 2–0 aos 29 e 34 minutos. Colidio diminui aos 38, assistido por Gómez.','- Braga promove Carlos Vinícius aos 59 no lugar de Gómez; Carlos faz o empate aos 78.','- Johan Rojas entra por Bruno Duarte aos 82 e, no mesmo minuto, faz o terceiro após assistência de Nuno Moreira.','- O desempenho não foi defensivamente dominante: Vasco 1,34 xG, Palmeiras 1,47 xG; a eficiência ofensiva decidiu.', '', '## Todos os jogos R25']
for r in d['results']:lines.append(f"- {r['home']} {r['hg']}–{r['ag']} {r['away']} | xG {r['hxg']:.2f}–{r['axg']:.2f}")
lines+=['','## Classificação após R25']
for i,r in enumerate(d['standings'],1):lines.append(f"{i}. {r['club']} — {r['pts']} pts | {r['w']}V {r['d']}E {r['l']}D | {r['gf']} GP / {r['ga']} GC, SG {r['gd']:+d}")
lines+=['','## Vasco — avaliação dos atletas']
for p in d['vasco_players']:lines.append(f"- {p['name']}: {p['minutes']}min, {p['goals']}G {p['assists']}A, {p['shots']} chutes, xG {p['xg']:.3f}, nota {p['rating']}, forma {p['form_before']:.3f}→{p['form_after']:.3f}")
lines+=['','## Treinamento de defesa','- Continuidade do trabalho defensivo, registrada ANTES do jogo de R25, aplica modesta redução de 0,06 xG à projeção pré-jogo do adversário. Isso não previne gols automaticamente e não muda OVR.','- Contra o Santos (R24): 0 gols sofridos, 1,55 xGA; contra o Palmeiras (R25): 2 gols sofridos, 1,47 xGA. Amostra de dois jogos insuficiente para declarar correção defensiva completa.','', '## Situação',f"- Confiança da diretoria: {d['board']}/100",f"- Caixa restrito SAF: R${d['cash']:,.2f}",f"- Jogos oficiais de Braga registrados: {d['manager_matches']}",'- Próximo Vasco: Mirassol x Vasco, 03/10/2027, R26', '', '## Verificações','- 250/380 jogos Brasileirão 2027 concluídos, 130 agendados','- Todas as partidas anteriores permanecem idênticas, sem rerolls ou edição dos placares','- Os 96 jogos da Libertadores e os 96 da Sul-Americana continuam preservados','- Chaveamentos continentais e 48 partidas da Copa do Brasil preservados; nenhuma eliminatória nova disputada neste episódio','- Salários, orçamento e transferências não alterados','- Cartões invalidados após substituição não foram registrados neste novo jogo; súmula de gols, tiros e assistências concilia','- O resultado Vasco 3–2 Palmeiras provém de uma execução determinística única do motor; desempenho, técnicos e treinamento registrados antes da partida','']
(P/'EPISODE_046.md').write_text('\n'.join(lines),encoding='utf-8')
w=Workbook.create()
def add(n,head,data,width=18):
 sh=w.worksheets.add(n);r=[list(head)]+[list(x) for x in data];sh.get_range_by_indexes(0,0,len(r),len(head)).values=r;sh.get_range_by_indexes(0,0,len(r),len(head)).format.column_width=width
 h=sh.get_range_by_indexes(0,0,1,len(head));h.format.fill='#173D39';h.format.font.color='#FFFFFF';h.format.font.bold=True;h.format.row_height=28
 sh.freeze_panes.freeze_rows(1)
 return sh
s=add('Overview',['Metric','Value'],[
 ('Episode',46),('Date','2027-09-26'),('Home','Vasco'),('Away','Palmeiras'),('Result',f"{v['hg']}–{v['ag']}"),('Vasco xG',v['hxg']),('Palmeiras xG',v['axg']),('Vasco shots',v['hs']),('Palmeiras shots',v['as']),('Vasco SOT',v['hst']),('Palmeiras SOT',v['ast']),('Attendance',v['att']),('Vasco position',next(i for i,r in enumerate(d['standings'],1) if r['club']=='Vasco')),('Vasco points',next(r['pts'] for r in d['standings'] if r['club']=='Vasco')),('Board confidence',d['board']),('SAF restricted cash',d['cash']),('Next match','Mirassol x Vasco 03/10/2027'),('Continued training','Opponent prematch expected xG -0.06 (before match)')],34)
add('R25 Results',['Home','HG','AG','Away','xG Home','xG Away','Shots Home','Shots Away','On Target H','On Target A'],[(r['home'],r['hg'],r['ag'],r['away'],r['hxg'],r['axg'],r['hs'],r['as'],r['hst'],r['ast']) for r in d['results']])
add('League Table',['Rank','Club','Played','W','D','L','GF','GA','GD','Points'],[(i,r['club'],r['played'],r['w'],r['d'],r['l'],r['gf'],r['ga'],r['gd'],r['pts']) for i,r in enumerate(d['standings'],1)])
add('Match Timeline',['Minute','Club','Player','Event','Assist','Out','xG'],[(e['minute'],e['club'],e['player'],e['type'],e.get('assist',''),e.get('out',''),e['xg']) for e in ve],20)
add('Vasco Match Players',['Player','Pos','OVR','Start','Mins','G','A','Shots','xG','Rating','Form Before','Form After'],[(p['name'],p['pos'],p['ovr'],p['starter'],p['minutes'],p['goals'],p['assists'],p['shots'],p['xg'],p['rating'],p['form_before'],p['form_after']) for p in d['vasco_players']])
add('Vasco Last 6',['Round','Date','Home','Away','HG','AG','Vasco GF','Vasco GA','Vasco xGA'],[(r['round'],r['datetime_local'],r['home'],r['away'],r['hg'],r['ag'],r['gf'],r['ga'],r['xga']) for r in d['vasco_last6']])
add('All Players',['ID','Club','Player','Pos','OVR','Fitness','Morale','G','A','Apps'],[(r['id'],r['club'],r['name'],r['pos'],r['ovr'],r['fitness'],r['morale'],r['goals'],r['assists'],r['apps']) for r in c.execute('select p.*,cl.name club from players p join clubs cl on p.club_id=cl.id')])
add('Brasileirao Calendar',['Date','Round','Home','Away','Status','HG','AG'],[(r['datetime_local'],r['round'],r['home'],r['away'],r['status'],r['home_goals'],r['away_goals']) for r in c.execute("select f.datetime_local,f.round,h.name home,a.name away,f.status,f.home_goals,f.away_goals from fixtures f join clubs h on h.id=f.home_id join clubs a on a.id=f.away_id where f.competition='Brasileirão 2027' order by f.datetime_local,f.id")])
add('Libertadores',['Group','Club','Pts','Played','GF','GA'],[(r['group_id'],r['club'],r['points'],r['played'],r['gf'],r['ga']) for r in c.execute('select * from libertadores_2027_groups')]);add('Sudamericana',['Group','Club','Pts','Played','GF','GA'],[(r['group_id'],r['club'],r['points'],r['played'],r['gf'],r['ga']) for r in c.execute('select * from sudamericana_2027_groups')])
add('Copa do Brasil',['Tie','Stage','Club A','Club B','Status','Winner'],[(r['tie_code'],r['stage'],r['club_a'],r['club_b'],r['status'],r['winner']) for r in c.execute('select * from cdb_2027_bracket')])
add('Finances',['Date','Category','Account','Amount BRL','Purpose'],[(r['dated'],r['category'],r['account'],r['amount_brl'],r['description']) for r in c.execute('select * from finance_ledger')],30)
add('Transfers',['Date','Player','From','To','Fee BRL'],[(r['dated'],r['player_name'],r['from_club_id'],r['to_club_id'],r['fee_brl']) for r in c.execute('select * from transfers')]) if False else None
add('Training',['Start','End','Club','Focus','Workload','Status','Note'],[(r['start_date'],r['end_date'],r['club'],r['focus'],r['workload'],r['effect_status'],r['coach_note']) for r in c.execute('select * from training_microcycles_2027')],25)
add('Method',['Parameter','Description'],[("Deterministic",'Single R25 simulation; sha256 fixture-seeded random sequences; no rerolls.'),("Tactical autonomy",'Braga lineup and substitutions based on form, fitness, position and in-match score.'),("Chemistry",'-.06 opponent prematch expected xG from defensive continuity set before kickoff.'),("No OVR editing",'Player abilities and football budgets left unchanged.'),("Integrity",'All prior results, continental events, transfer records and finance ledger compared with Save045.')],40)
print('Inspect',w.inspect({'kind':'table','range':'Overview!A1:B9','include':'values','table_max_rows':9,'table_max_cols':2}).ndjson[:1100]);
path=P/'braga_player_database_046.xlsx';SpreadsheetFile.export_xlsx(w).save(str(path))
c.close();assert path.exists() and path.stat().st_size>10000
archive=B/'Braga_Era_SAVE_046.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for fp in sorted(P.iterdir()):
  if fp.is_file() and fp.name!='run_log.json':z.write(fp,'Save046/'+fp.name)
 z.write(B/'Braga_Era_SAVE_045.zip','Previous/Braga_Era_SAVE_045.zip')
 z.write(B/'run046.py','repro/run046.py');z.write(B/'build046.py','repro/build046.py')
assert archive.exists()
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert 'Save046/braga_save.sqlite' in z.namelist()
print('ARTIFACTS',[(str(x),x.stat().st_size) for x in [archive,path,P/'EPISODE_046.md',P/'results046.json']])
