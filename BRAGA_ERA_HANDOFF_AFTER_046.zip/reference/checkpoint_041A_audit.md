# THE BRAGA ERA — CHECKPOINT 041A — AUDIT ONLY

**Timeline:** August 25, 2027, after Vasco 1–3 Fluminense (Copa do Brasil Round-of-16 second leg).

**State:** No games simulated, no rerolls, no team/player/finance updates. Canonical SQLite is the exact byte-for-byte copy of Save 041.

## Brasileirão 2027

- 380 valid scheduled pairings (each of 20 clubs faces each other home and away).
- Rounds 1–20: 200 completed games, 10 per round, all scores present.
- Rounds 21–38: 180 scheduled games, 10 per round, future dates populated and results unset.
- Every round has all 20 clubs exactly once, no duplicated appearances.
- All club points, W-D-L, goals for and against agree with independently recomputed results.
- Match shot goals agree with scores wherever shot-level data exists.

## Copa do Brasil 2027

- Round of 32: 16 completed ties / 32 played legs.
- Round of 16: 8 completed ties / 16 played legs.
- 2 penalty-decided tied aggregates, with valid winners in bracket.
- For every completed tie, clubs' home/away legs reversed correctly; winner is valid relative to aggregate, and advanced into assigned next bracket slot.
- Quarterfinals: 4 ties scheduled, no played legs or winners.
- Shot-goal counts agree with match scores where detailed shots are present.

## Result

**All performed checks passed; 0 discrepancies.**

### Scope limitations
This is a structural/arithmetical audit, not independent verification that all fictional events represent a real-world calendar or that every past match narrative has minute-perfect correspondence with events. No results changed.

## Next canonical event
August 29, 2027: Vasco x Vitória, Brasileirão round 21.
