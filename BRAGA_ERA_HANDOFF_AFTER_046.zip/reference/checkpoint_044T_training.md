# CHECKPOINT 044T — Defesa e entrosamento

**Base:** Save 044 (12/09/2027), nenhum jogo adicional simulado.
**Próximo jogo:** Santos x Vasco, 19/09/2027.

Treinos planejados de 13 a 18 de setembro:
- 13–14: compactação e transição defensiva, 11v11, coordenação dos volantes e dos laterais.
- 15: comunicação e entrosamento da zaga, integrações Arthur Dias/Cuesta/Robert Renan/Saldivia, comandos de Léo Jardim.
- 16: bolas paradas, segunda bola, e proteger placares de 1–0 a partir de 65 minutos.
- 17–18: revisão em vídeo e recuperação física, com carga leve antes do Santos.

**Métricas de avaliação nas rodadas seguintes:** xGA nos primeiros 20 minutos, gols sofridos em bolas paradas, erros que viram finalização, pontos cedidos após estar vencendo e proporção de jogos sem sofrer gols.

Treinar não determina resultado: nenhum rating foi artificialmente elevado, nenhuma partida foi simulada nem alterada, e não há clean sheet garantido. O histórico competitivo e financeiro segue intacto.
