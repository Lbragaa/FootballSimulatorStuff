"""Braga Era 012. Auditable alternate-history 2027 league round 1.
Inputs: Save011 canonical sqlite; first 81 fixtures immutable. 2027 promoted clubs fictional,
2026 Serie B participants factual; lineup names inspired by published 2026 base XIs.
"""
import sqlite3,random,math,json,shutil,hashlib,csv,collections,datetime
from pathlib import Path
ROOT=Path(__file__).parent; SRC=ROOT.parent/'work011'/'braga_save.sqlite'; DB=ROOT/'braga_save.sqlite'
shutil.copy2(SRC,DB)
c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON')
assert c.execute("select value from meta where key='saved_state_version'").fetchone()[0]=='011'
old_fixtures={r['id']:tuple(r) for r in c.execute('select * from fixtures')}
assert len(old_fixtures)==81
legacy_player_count=c.execute('select count(*) from players').fetchone()[0]
assert legacy_player_count==474
assert c.execute("select count(*) from transfers").fetchone()[0]==3

def rng_for(*args):
 s='-'.join(str(x) for x in args).encode();return random.Random(int(hashlib.sha256(s).hexdigest()[:15],16))
def clamp(x,lo,hi):return max(lo,min(x,hi))
def poisson(rng,lam):
 if lam<=0:return 0
 cutoff=math.exp(-lam);a=1;k=0
 while a>cutoff:k+=1;a*=rng.random()
 return k-1

# Four promoted clubs are IN-UNIVERSE fictitious 2026 Serie B result;
# these 2026 line-up reference names come from a previously published club preview.
newclubs=[
('Fortaleza',72.5,[('Brenno','GK'),('Mailton','DF'),('Emanuel Brítez','DF'),('Cardona','DF'),('Fuentes','DF'),('Lucas Sasha','MF'),('Pierre','MF'),('Rodrigo','MF'),('Lucas Crispim','MF'),('Tomás Pochettino','FW'),('Luiz Fernando','FW'),('Gazal','DF'),('Moisés','FW')]),
('Ceará',71.2,[('Richard','GK'),('Rafael Ramos','DF'),('Éder','DF'),('Luizão','DF'),('Fernando','DF'),('Zanocelo','MF'),('Lucas Lima','MF'),('Vina','MF'),('Matheusinho','FW'),('Matheus Araújo','FW'),('Wendel Silva','FW'),('Melk','FW')]),
('Goiás',70.8,[('Tadeu','GK'),('Diego Caito','DF'),('Luis Felipe','DF'),('Lucas Ribeiro','DF'),('Nicolas','DF'),('Gegê','MF'),('Filipe Machado','MF'),('Lourenço','MF'),('Jean Carlos','FW'),('Lucas Lima','FW'),('Anselmo Ramon','FW'),('David Braz','DF')]),
('Sport',70.3,[('Thiago Couto','GK'),('Felipinho','DF'),('Marcelo Ajul','DF'),('Matheus Benevenuto','DF'),('Pucci','DF'),('Zé Gabriel','MF'),('Zé Lucas','MF'),('Yago Felipe','MF'),('Gustavo Maia','FW'),('Chrystian Barletta','FW'),('Iury Castilho','FW'),('Lucas André','MF')])]
source='https://diariodonordeste.verdesmares.com.br/jogada/guia-da-serie-b-do-brasileiro-2026-veja-participantes-times-base-e-projecoes-para-cada-clube-1.3751581'
for name,strength,squad in newclubs:
 c.execute('''INSERT INTO clubs(name,strength,form,played,wins,draws,losses,gf,ga,points) VALUES(?,?,0,0,0,0,0,0,0,0)''',(name,strength))
 id_=c.execute('select last_insert_rowid()').fetchone()[0]
 for i,(namep,pos) in enumerate(squad):
  rng=rng_for(name,namep,'rating');ovr=round(clamp(strength-2+rng.uniform(-3.8,3.8),64,77));potential=max(ovr,ovr+rng.randrange(0,8))
  attack=round(clamp(ovr+({'FW':8,'MF':3,'DF':-20,'GK':-45}[pos])+rng.randrange(-6,7),10,95))
  defense=round(clamp(ovr+({'FW':-25,'MF':0,'DF':10,'GK':-20}[pos])+rng.randrange(-6,7),8,96))
  passing=round(clamp(ovr+rng.randrange(-7,9),40,88))
  physical=round(clamp(ovr+rng.randrange(-9,10),45,90))
  composure=round(clamp(ovr+rng.randrange(-12,8),43,90))
  c.execute('''INSERT INTO players(club_id,name,pos,ovr,potential,career_phase,attack,defense,passing,physical,composure,goalkeeping,fitness,morale,source_url,source_status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(id_,namep,pos,ovr,potential,'senior',attack,defense,passing,physical,composure,ovr if pos=='GK' else 15,94,58,source,'2026 suggested base XI; 2027 fictional carry-over and rating'))
 # simple fictional academy bench, not fake claims about real players
 for i,pos in enumerate(['GK','DF','DF','MF','MF','FW'],1):
  r=rng_for(name,i,'academy');ovr=r.randint(59,66)
  c.execute('''INSERT INTO players(club_id,name,pos,ovr,potential,career_phase,attack,defense,passing,physical,composure,goalkeeping,fitness,morale,source_url,source_status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(id_,f'{name} Academy #{i:02d}',pos,ovr,ovr+r.randrange(5,13),'prospect',ovr+4 if pos=='FW' else ovr-8,ovr+4 if pos=='DF' else ovr-6,ovr,ovr,ovr-4,ovr if pos=='GK' else 12,97,60,'','synthetic fictional academy depth player'))

# Freeze 2026 league stats in archive before resetting only seasonal counters
c.execute('''CREATE TABLE IF NOT EXISTS league_participants (season INTEGER NOT NULL,club_id INTEGER NOT NULL,origin TEXT NOT NULL,PRIMARY KEY(season,club_id))''')
relegated=['Internacional','Grêmio','Remo','Chapecoense']
survivors=[r['name'] for r in c.execute('SELECT name FROM clubs WHERE id<=20') if r['name'] not in relegated]
assert len(survivors)==16
for name in survivors+ [x[0] for x in newclubs]:
 ident=c.execute('select id from clubs where name=?',(name,)).fetchone()[0]
 c.execute('insert into league_participants values (2027,?,?)',(ident,'promoted from 2026 Serie B (fictional)' if name in [x[0] for x in newclubs] else '2026 Serie A survivor'))
c.execute('UPDATE clubs SET played=0,wins=0,draws=0,losses=0,gf=0,ga=0,points=0,form=0')
# restore 6-12 fitness after several days recovery, without inventing ratings
c.execute("UPDATE players SET fitness=MIN(100,fitness+7),injury='' WHERE club_id IN (select club_id from league_participants where season=2027)")

# Construct all 380 domestic pairings; the round dates after R2 are provisional/TBD.
# First round Vasco hosts Fortaleza; no team sees identical opponent twice at home.
others=sorted([n for n in survivors+[x[0] for x in newclubs] if n not in ('Vasco','Fortaleza')])
order=['Vasco']+others+['Fortaleza'];assert len(order)==20
rounds=[];seen=set()
for round_n in range(1,20):
 pairs=[]
 for i in range(10):
  a,b=order[i],order[19-i]
  home,away=(a,b) if (i+round_n)%2==1 else (b,a)
  if round_n==1 and i==0:home,away='Vasco','Fortaleza'
  pairs.append((home,away))
  key=frozenset((a,b));assert key not in seen;seen.add(key)
 rounds.append(pairs)
 order=[order[0],order[-1]]+order[1:-1]
assert len(seen)==190
return_legs=[[(a,b) for b,a in r] for r in rounds]
all_rounds=rounds+return_legs
assert len(all_rounds)==38
for ri,pairs in enumerate(all_rounds,1):
 for mi,(home,away) in enumerate(pairs):
  dt=('2027-03-13 19:00' if home=='Vasco' and ri==1 else '2027-03-14 '+f'{16+mi%4}:00') if ri==1 else ('2027-03-20 19:00' if (home=='Vasco' or away=='Vasco') and ri==2 else None)
  c.execute("INSERT INTO fixtures(datetime_local,home_id,away_id,competition,round,status) VALUES(?,?,?,?,?,'scheduled')",(dt,c.execute('select id from clubs where name=?',(home,)).fetchone()[0],c.execute('select id from clubs where name=?',(away,)).fetchone()[0],'Brasileirão 2027',f'R{ri:02d}'))
assert c.execute("select count(*) from fixtures where competition='Brasileirão 2027'").fetchone()[0]==380
assert c.execute("select count(*) from fixtures where competition='Brasileirão 2027' and round='R01'").fetchone()[0]==10
# 2027 competition timing diverted from 2027 real CBF calendar due to abridged state championship season.
c.execute("INSERT OR REPLACE INTO season_rules VALUES(2027,'Brasileirão 2027','fictional_calendar','March 13 fictional kickoff, diverges from real CBF Jan 27 start because Save 011 advanced through Carioca; 38 round-robin rounds, later dates provisional, honor mid-year FIFA Women World Cup break in later scheduling.')")
c.execute("INSERT OR REPLACE INTO season_rules VALUES(2027,'Brasileirão 2027','qualification','Top league spots contingent on 2027 2028 CONMEBOL/CBF allocations and cup champions; 17th-20th relegated. Do not award early continental berths.')")
c.execute("INSERT OR REPLACE INTO season_rules VALUES(2027,'Brasileirão 2027','promotions','Fictional 2026 Serie B promoted: Fortaleza, Ceará, Goiás, Sport. No real-world 2026 Serie B results assumed.')")
c.execute('INSERT INTO decisions(dated,category,decision,impact) VALUES(?,?,?,?)',('2027-03-11','tactics','Braga selects 4-2-3-1 vs Fortaleza; Carlos Vinícius starts; Villagra and Gustavo Martins trusted','Attack through Lescano, Gómez and Colidio; layered wing pressure. No last-minute transfers or reserve unlocking.'))

vasco_pref=['Léo Jardim','Paulo Henrique','Gustavo Martins','Robert Renan','Lucas Piton','Santiago Sosa','Rodrigo Villagra','Alan Lescano','Andrés Gómez','Facundo Colidio','Carlos Vinícius']

def pick(rng,ps,weights):return rng.choices(ps,weights=[max(.02,weights(p)) for p in ps],k=1)[0]
def lineup(teamid,teamname):
 ps=[dict(r) for r in c.execute("select * from players where club_id=? and injury=''",(teamid,))]
 pref=vasco_pref if teamname=='Vasco' else []
 starters=[]
 for n in pref:
  p=next((q for q in ps if q['name']==n),None)
  if p and p not in starters:starters.append(p)
 target={'GK':1,'DF':4,'MF':3,'FW':3}
 for role,n in target.items():
  have=sum(p['pos']==role for p in starters)
  pool=sorted((p for p in ps if p['pos']==role and p not in starters),key=lambda p:p['ovr']+.05*p['fitness']+.01*p['morale'],reverse=True)
  starters+=pool[:max(0,n-have)]
 for p in sorted(ps,key=lambda p:p['ovr'],reverse=True):
  if len(starters)>=11:break
  if p not in starters:starters.append(p)
 assert len(starters)==11,(teamname,len(starters))
 subs=[p for p in ps if p['id'] not in [q['id'] for q in starters]]
 return starters,subs

def simulate(fid):
 fix=dict(c.execute('select * from fixtures where id=?',(fid,)).fetchone());assert fix['status']=='scheduled'
 h=dict(c.execute('select * from clubs where id=?',(fix['home_id'],)).fetchone());a=dict(c.execute('select * from clubs where id=?',(fix['away_id'],)).fetchone());rng=rng_for('braga2027',fid)
 hxi,hbench=lineup(h['id'],h['name']);axi,abench=lineup(a['id'],a['name']);starting={h['id']:hxi,a['id']:axi}
 active={h['id']:list(hxi),a['id']:list(axi)};bench={h['id']:hbench,a['id']:abench}
 particip={p['id']:{'club_id':cl,'starter':1,'minutes':90,'goals':0,'assists':0,'shots':0,'xg':0} for cl,ls in starting.items() for p in ls}
 def q(team,xi):return .71*team['strength']+.29*sum(p['ovr'] for p in xi)/11+.22*team['form']+.02*(sum(p['fitness'] for p in xi)/11-87)
 qh,qa=q(h,hxi),q(a,axi)
 hx_base=clamp(1.35+.20+.054*(qh-qa),.45,2.55);ax_base=clamp(1.20+.054*(qa-qh),.38,2.3)
 # Prior tactical decision: Vasco home take measured attacking initiative, may trade space for chances
 if h['name']=='Vasco':hx_base+=.08;ax_base+=.04
 packs=[]
 for team,lam in [(h,hx_base),(a,ax_base)]:
  shot_count=max(5,min(21,poisson(rng,11+.08*(team['strength']-72))))
  raw=[clamp(rng.betavariate(1.5,12),.016,.45) for _ in range(shot_count)];factor=lam/sum(raw)
  for val in raw:
   xg=clamp(val*factor,.014,.68);m=rng.randint(3,93)
   packs.append(dict(minute=m,team_id=team['id'],xg=round(xg,4),goal=int(rng.random()<xg)))
 packs.sort(key=lambda p:(p['minute'],p['team_id']))
 cards=[]
 for cl,ls in [(h['id'],hxi),(a['id'],axi)]:
  for j in range(min(4,poisson(rng,1.55))):
   p=pick(rng,[p for p in ls if p['pos']!='GK'],lambda x:2 if x['pos']=='DF' else 1.5 if x['pos']=='MF' else .6)
   cards.append(dict(minute=rng.randint(10,90),team_id=cl,player_id=p['id']))
 # Card-generation dedup: a player cannot receive three separate yellow cards without dismissal.
 # We model at most one yellow per player in this lightweight engine; red cards can be implemented later.
 unique_cards=[];seen_card_ids=set()
 for item in cards:
  if item['player_id'] not in seen_card_ids:
   seen_card_ids.add(item['player_id']);unique_cards.append(item)
 cards=unique_cards
 timeline=[]
 for x in packs:timeline.append((x['minute'],2,'SHOT',x))
 for x in cards:timeline.append((x['minute'],3,'YELLOW',x))
 for team in [h,a]:
  for m in ([59,73,82] if team['name']=='Vasco' else [65,78]):timeline.append((m,1,'TACTICAL_SUB',{'team_id':team['id'],'minute':m}))
 timeline.sort(key=lambda e:(e[0],e[1]))
 scored={h['id']:0,a['id']:0};ev=[];sh=[];subs=[]
 for minute,prio,typ,event in timeline:
  club=event['team_id']
  if typ=='TACTICAL_SUB':
   if not bench[club]:continue
   opp=a['id'] if club==h['id'] else h['id'];trailing=scored[club]<scored[opp]
   # Dynamic managerial choice based on score at that exact minute
   if trailing and minute<82:preferred=['FW','MF','DF']
   elif scored[club]>scored[opp]:preferred=['MF','DF','FW']
   else:preferred=['FW','MF','DF']
   subpair=None
   for pos in preferred:
    outgoing=[x for x in active[club] if x['pos']==pos and x['pos']!='GK']
    incoming=[x for x in bench[club] if x['pos']==pos]
    if outgoing and incoming:
     who=sorted(outgoing,key=lambda p:(p['fitness'],-p['ovr']))[0]
     new=sorted(incoming,key=lambda p:p['ovr']+.03*p['fitness'],reverse=True)[0]
     subpair=(who,new);break
   if not subpair:continue
   outgoing,incoming=subpair
   active[club].remove(outgoing);active[club].append(incoming);bench[club].remove(incoming)
   particip[outgoing['id']]['minutes']=min(particip[outgoing['id']]['minutes'],minute)
   particip[incoming['id']]={'club_id':club,'starter':0,'minutes':90-minute,'goals':0,'assists':0,'shots':0,'xg':0}
   ev.append((minute,club,incoming['id'],'SUBSTITUTION',0,f'out:{outgoing["id"]}'))
   subs.append(dict(minute=minute,club=c.execute('select name from clubs where id=?',(club,)).fetchone()[0],off=outgoing['name'],on=incoming['name']))
  elif typ=='YELLOW':ev.append((minute,club,event['player_id'],'YELLOW',0,''))
  else:
   ls=active[club];p=pick(rng,[x for x in ls if x['pos']!='GK'],lambda p:max(1,(p['attack']/72)**2)*{'DF':.45,'MF':2.5,'FW':6.1}[p['pos']]);xg=event['xg'];goal=event['goal']
   ont=1 if goal else int(rng.random()<clamp(.22+xg*1.03,.20,.75))
   particip[p['id']]['shots']+=1;particip[p['id']]['xg']+=xg;particip[p['id']]['goals']+=goal
   asst=None
   if goal:
    scored[club]+=1
    if rng.random()<.72:
     others=[x for x in ls if x['id']!=p['id']]
     asst=pick(rng,others,lambda x:{'GK':.02,'DF':.9,'MF':3.2,'FW':2.2}[x['pos']] * (x['passing']/72)**2)
     particip[asst['id']]['assists']+=1
    ev.append((minute,club,p['id'],'GOAL',xg,'assist:'+str(asst['id']) if asst else 'unassisted'))
   sh.append((minute,club,p['id'],xg,ont,goal,fix['round']))
 # Rare injuries: only ~1.5% per match, 3-6 day absence, if sampled.
 injuries=[]
 if rng.random()<.015:
  cl= rng.choice([h['id'],a['id']]);p=rng.choice([x for x in active[cl] if x['pos']!='GK']);c.execute("UPDATE players SET injury='minor muscle strain (5 days)' WHERE id=?",(p['id'],));injuries.append(p['name'])
 hg,ag=scored[h['id']],scored[a['id']]
 hxg=round(sum(x[3] for x in sh if x[1]==h['id']),2);axg=round(sum(x[3] for x in sh if x[1]==a['id']),2)
 hs=sum(x[1]==h['id'] for x in sh);ass=len(sh)-hs
 hst=sum(x[4] for x in sh if x[1]==h['id']);ast=sum(x[4] for x in sh if x[1]==a['id'])
 possession=round(clamp(51+(qh-qa)*.62+rng.gauss(0,5),36,66));att=rng.randint(17000,38000) if h['name']=='Vasco' else rng.randint(10000,48000)
 c.execute('''UPDATE fixtures SET status='final',home_goals=?,away_goals=?,home_xg=?,away_xg=?,home_shots=?,away_shots=?,home_sot=?,away_sot=?,home_possession=?,away_possession=?,attendance=?,report=? WHERE id=?''',(hg,ag,hxg,axg,hs,ass,hst,ast,possession,100-possession,att,f'fictional 2027 shot-level match engine sha256 seed braga2027-{fid}; quality {qh:.1f}-{qa:.1f}; prematch expected xG {hx_base:.2f}-{ax_base:.2f}',fid))
 for minute,cl,pid,xg,ont,goal,phase in sh:c.execute('INSERT INTO shots(fixture_id,minute,club_id,player_id,xg,on_target,goal,phase) VALUES(?,?,?,?,?,?,?,?)',(fid,minute,cl,pid,xg,ont,goal,phase))
 for event in sorted(ev,key=lambda e:e[0]):c.execute('INSERT INTO events(fixture_id,minute,club_id,player_id,event_type,xg,notes) VALUES(?,?,?,?,?,?,?)',(fid,*event))
 for team,opp in [(h,a),(a,h)]:
  g=scored[team['id']];ga=scored[opp['id']];win=int(g>ga);draw=int(g==ga);lose=int(g<ga)
  c.execute('''UPDATE clubs SET played=played+1,wins=wins+?,draws=draws+?,losses=losses+?,points=points+?,gf=gf+?,ga=ga+?,form=MAX(-3,MIN(3,form*.8+?)) WHERE id=?''',(win,draw,lose,3*win+draw,g,ga,1 if win else -.7 if lose else 0,team['id']))
 for pid,stats in particip.items():
  team=stats['club_id'];win=int(scored[team]>scored[a['id'] if team==h['id'] else h['id']]);draw=int(hg==ag)
  p=dict(c.execute('select * from players where id=?',(pid,)).fetchone())
  rolebonus=.10 if p['pos']=='GK' else 0
  r=round(clamp(6.45+(p['ovr']-72)*.033+stats['goals']*.86+stats['assists']*.55+(.19 if win else .04 if draw else -.17)+rolebonus,5.2,9.8),1)
  c.execute('''INSERT INTO player_matches(fixture_id,player_id,club_id,starter,minutes,goals,assists,shots,xg,rating) VALUES(?,?,?,?,?,?,?,?,?,?)''',(fid,pid,team,stats['starter'],stats['minutes'],stats['goals'],stats['assists'],stats['shots'],round(stats['xg'],3),r))
  c.execute('''INSERT INTO player_season_totals(season,competition,player_id,club_id,apps,minutes,goals,assists,shots,xg,rating_sum) VALUES(2027,'Brasileirão 2027',?,?,?,?,?,?,?,?,?) ON CONFLICT(season,competition,player_id) DO UPDATE SET apps=apps+1,minutes=minutes+excluded.minutes,goals=goals+excluded.goals,assists=assists+excluded.assists,shots=shots+excluded.shots,xg=xg+excluded.xg,rating_sum=rating_sum+excluded.rating_sum''',(pid,team,1,stats['minutes'],stats['goals'],stats['assists'],stats['shots'],round(stats['xg'],3),r))
  c.execute('''UPDATE players SET apps=apps+1,minutes=minutes+?,goals=goals+?,assists=assists+?,shots=shots+?,xg=xg+?,rating_total=rating_total+?,fitness=MAX(68,fitness-?),morale=MAX(30,MIN(100,morale+?)) WHERE id=?''',(stats['minutes'],stats['goals'],stats['assists'],stats['shots'],round(stats['xg'],3),r,rng.randint(3,8),2 if win else -2 if not draw else 0,pid))
 if 'Vasco' in (h['name'],a['name']):
  c.execute('UPDATE meta SET value=CAST(CAST(value AS INTEGER)+1 AS TEXT) WHERE key="braga_matches"')
  old=int(c.execute("select value from meta where key='board_confidence'").fetchone()[0]);iswin=(h['name']=='Vasco' and hg>ag) or (a['name']=='Vasco' and ag>hg)
  new=clamp(old+ (3 if iswin else -2 if hg!=ag else 0),0,100);c.execute("UPDATE meta SET value=? WHERE key='board_confidence'",(str(new),))
  c.execute('INSERT INTO news(dated,headline,body,type) VALUES(?,?,?,?)',(fix['datetime_local'] or '2027-03-14',f"Brasileirão: {h['name']} {hg}-{ag} {a['name']}",f"Round {fix['round']} fictional result; xG {hxg}-{axg}",'fictional'))
  c.execute('INSERT INTO decisions(dated,category,decision,impact) VALUES(?,?,?,?)',(fix['datetime_local'] or '2027-03-14','match',f"Braga manages {h['name']} vs {a['name']} in 2027 Serie A",f'{hg}-{ag}; xG {hxg}-{axg}; substitute log persisted'))
 return {'id':fid,'home':h['name'],'away':a['name'],'hg':hg,'ag':ag,'hxg':hxg,'axg':axg,'hs':hs,'as':ass,'hst':hst,'ast':ast,'possession_h':possession,'att':att,'events':[(m,c.execute('select name from players where id=?',(pid,)).fetchone()[0],typ,c.execute('select name from clubs where id=?',(team,)).fetchone()[0],note) for m,team,pid,typ,xg,note in sorted(ev)],'subs':subs,'injuries':injuries,'seed_key':f'braga2027-{fid}'}

# record Jan/Feb monthly additional wage payroll; board still tracks full annual obligations as commitment
paidmonths=[row['description'] for row in c.execute("select description from finance_ledger where category='incremental wage payroll'")]
wage=sum(row['wage_monthly_brl'] for row in c.execute('select wage_monthly_brl from transfer_contracts'))
for mo in [1,2]:
 label=f'2027-{mo:02d}'
 if not any(label in s for s in paidmonths):
  c.execute('''INSERT INTO finance_ledger(dated,category,account,amount_brl,restricted_for,description,fictional) VALUES(?,?,?,?,?,?,1)''',(f'2027-{mo:02d}-{31 if mo==1 else 28}','incremental wage payroll','2027 football restricted account',-wage,'Incremental wages',f'{label}: monthly wages for Braga 2027 signings (without double-counting annual commitment)'))

round1=[row['id'] for row in c.execute("select id from fixtures where competition='Brasileirão 2027' and round='R01' order by datetime_local,id")]
res=[simulate(fid) for fid in round1]
vasco=next(v for v in res if 'Vasco' in (v['home'],v['away']))
assert vasco['home']=='Vasco' and vasco['away']=='Fortaleza',vasco
assert len(res)==10
c.execute("UPDATE meta SET value=? WHERE key='current_date'",('2027-03-14 22:30',))
c.execute("UPDATE meta SET value=? WHERE key='saved_state_version'",('012',))
c.execute("INSERT OR REPLACE INTO meta VALUES('2027_brasileirao_status','Round 01 all 10 games played; 38-round schedule created, 370 remaining fixtures scheduled; 2026 standings archived independently')")
c.execute("INSERT OR REPLACE INTO meta VALUES('next_fixtures_confirmation','2027 Serie A Round 02 pairings generated, provisional date 2027-03-20; Sul-Americana and Copa do Brasil not yet simulated')")
c.execute("UPDATE meta SET value=? WHERE key='manager_tactical_familiarity'",('56',))
c.commit()

# audits 
assert c.execute('pragma integrity_check').fetchone()[0]=='ok'
assert c.execute("select count(*) from fixtures where competition='Brasileirão 2027' and status='final'").fetchone()[0]==10
assert c.execute("select count(*) from fixtures where competition='Brasileirão 2027' and status='scheduled'").fetchone()[0]==370
assert c.execute('select count(*) from players').fetchone()[0]==legacy_player_count+sum(len(s)+6 for _,_,s in newclubs)
assert c.execute('select count(*) from league_standings_archive where season=2026').fetchone()[0]==20
assert c.execute('select count(*) from transfers').fetchone()[0]==3
for id_,old in old_fixtures.items():assert tuple(c.execute('select * from fixtures where id=?',(id_,)).fetchone())==old,id_
for club in c.execute("select cl.* from clubs cl join league_participants lp on lp.club_id=cl.id where lp.season=2027"):
 assert club['played']==1 and club['wins']+club['draws']+club['losses']==1 and club['points']==3*club['wins']+club['draws'],club['name']
for fix in c.execute("select * from fixtures where competition='Brasileirão 2027' and status='final'"):
 fid=fix['id'];evgoals=c.execute('select count(*) from events where fixture_id=? and event_type="GOAL"',(fid,)).fetchone()[0]
 assert evgoals==fix['home_goals']+fix['away_goals']
 assert c.execute('select sum(goals) from player_matches where fixture_id=?',(fid,)).fetchone()[0]==evgoals
 assert c.execute('select sum(goal) from shots where fixture_id=?',(fid,)).fetchone()[0]==evgoals
 assert c.execute('select sum(assists) from player_matches where fixture_id=?',(fid,)).fetchone()[0]==c.execute('select count(*) from events where fixture_id=? and notes like "assist:%"',(fid,)).fetchone()[0]
 for club_id,xg,shots,sot in [(fix['home_id'],fix['home_xg'],fix['home_shots'],fix['home_sot']),(fix['away_id'],fix['away_xg'],fix['away_shots'],fix['away_sot'])]:
  r=c.execute('select sum(xg),count(*),sum(on_target) from shots where fixture_id=? and club_id=?',(fid,club_id)).fetchone()
  assert round(r[0],2)==xg and r[1]==shots and r[2]==sot,(fid,club_id,r,xg,shots,sot)
# table sorted by wins as official first breaker
standing=[dict(x) for x in c.execute("select cl.* from clubs cl join league_participants lp on lp.club_id=cl.id where lp.season=2027")]
standing.sort(key=lambda d:(-d['points'],-d['wins'],-(d['gf']-d['ga']),-d['gf'],d['name']))
rowsh=[{'position':i,'club':x['name'],'played':x['played'],'w':x['wins'],'d':x['draws'],'l':x['losses'],'gf':x['gf'],'ga':x['ga'],'gd':x['gf']-x['ga'],'pts':x['points']} for i,x in enumerate(standing,1)]
nextfix=[dict(r) for r in c.execute('''select f.round, h.name home,a.name away,f.datetime_local as kickoff from fixtures f join clubs h on h.id=f.home_id join clubs a on a.id=f.away_id where f.competition='Brasileirão 2027' and f.round='R02' order by f.id''')]
for table in ['clubs','players','fixtures','shots','events','player_matches','player_season_totals','decisions','news','transfers','transfer_contracts','league_standings_archive','league_participants','finance_budget','finance_ledger','season_rules','meta']:
 cur=c.execute('select * from '+table)
 with open(ROOT/(table+'.csv'),'w',newline='',encoding='utf-8-sig') as f:
  w=csv.writer(f);w.writerow([x[0] for x in cur.description]);w.writerows(cur.fetchall())
report={'chapter':12,'saved_at':'2027-03-14 22:30','model':'shot-level chance generation first, Bernoulli goals, live score-sensitive substitutions','promotions':[x[0] for x in newclubs],'vasco':vasco,'round1':res,'table':rowsh,'round2':nextfix,'manager_matches':int(c.execute("select value from meta where key='braga_matches'").fetchone()[0]),'board_confidence':int(c.execute("select value from meta where key='board_confidence'").fetchone()[0]),'finances':{'approved_fees':55e6,'committed_fees':48e6,'remaining_fee_cap':7e6,'incremental_monthly_wages':wage,'cumulative_cash_payroll':2*wage,'cash_balance':sum(r['amount_brl'] for r in c.execute("select * from finance_ledger where account='2027 football restricted account'"))},'audits':{'integrity':'ok','historical_fixtures_untouched':81,'2027_scheduled':370,'2027_completed':10,'2027_participants':20,'current_players':c.execute('select count(*) from players').fetchone()[0]}}
(ROOT/'results012.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'vasco':vasco,'results':[{k:v for k,v in m.items() if k in ('home','away','hg','ag','hxg','axg')} for m in res],'table':rowsh,'next_vasco':next((r for r in nextfix if 'Vasco' in (r['home'],r['away'])),None),'finances':report['finances'],'audits':report['audits']},ensure_ascii=False,indent=2))
c.close()
