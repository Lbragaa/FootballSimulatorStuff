# THE BRAGA ERA — Episode 045

2027-09-19 | Santos vs Vasco | Brasileirão R24

## Santos 0–2 Vasco

xG 1.55–1.2; shots 10–11; SOT 4–5

## Events
- 14' Arthur Melo YELLOW [Santos] 
- 26' Robert Renan YELLOW [Vasco] 
- 27' Andrés Gómez GOAL [Vasco] assist:4
- 35' Andrés Gómez GOAL [Vasco] assist:163
- 59' Thiago Mendes SUBSTITUTION [Vasco] out:15
- 65' Rony SUBSTITUTION [Santos] out:312
- 67' Paulo Henrique YELLOW [Vasco] 
- 73' Cuiabano YELLOW [Vasco] 
- 73' Álvaro Barreal SUBSTITUTION [Vasco] out:13
- 78' Thaciano SUBSTITUTION [Santos] out:309
- 82' Cauan Barros SUBSTITUTION [Vasco] out:163
- 84' Alan Lescano YELLOW [Vasco] 

## Brasileirão R24
- Santos 0–2 Vasco
- Sport 1–2 Palmeiras
- Mirassol 1–0 São Paulo
- Vitória 2–1 Goiás
- Fluminense 2–2 Fortaleza
- Athletico-PR 2–2 Flamengo
- Cruzeiro 2–1 Atlético-MG
- Bahia 2–1 Coritiba
- Corinthians 3–0 Botafogo
- Bragantino 3–0 Ceará

## League table
1. Flamengo 52 pts GD 29
2. Palmeiras 51 pts GD 28
3. São Paulo 48 pts GD 11
4. Corinthians 39 pts GD 11
5. Bahia 39 pts GD 6
6. Botafogo 38 pts GD 5
7. Fluminense 38 pts GD 16
8. Cruzeiro 38 pts GD 9
9. Atlético-MG 36 pts GD 5
10. Vasco 35 pts GD -2
11. Santos 32 pts GD 5
12. Fortaleza 32 pts GD 2
13. Bragantino 31 pts GD -2
14. Ceará 29 pts GD -4
15. Coritiba 24 pts GD -10
16. Vitória 22 pts GD -10
17. Athletico-PR 22 pts GD -14
18. Mirassol 21 pts GD -15
19. Goiás 16 pts GD -28
20. Sport 12 pts GD -42

## Defense training measured
{
  "last5_before_training": {
    "matches": 5,
    "gf": 8,
    "ga": 6,
    "xgf": 8.08,
    "xga": 6.04,
    "clean_sheets": 0,
    "goals_conceded_first20": 2,
    "xga_first20": 1.3
  },
  "santos_after_training": {
    "matches": 1,
    "gf": 2,
    "ga": 0,
    "xgf": 1.2,
    "xga": 1.55,
    "clean_sheets": 1,
    "goals_conceded_first20": 0,
    "xga_first20": 0.49
  },
  "season_to_R24": {
    "matches": 24,
    "gf": 33,
    "ga": 35,
    "xgf": 35.83,
    "xga": 32.0,
    "clean_sheets": 3,
    "goals_conceded_first20": 10,
    "xga_first20": 7.09
  }
}

## Predictions after R24
Forecast scenarios only; 4,000 Monte Carlo rollouts, independent of canonical season; NOT results or guaranteed odds.
- Palmeiras: 76.3 projected pts; top4 99.9%; top6 100.0%; top8 100.0%; relegation 0.0%; last5 DDLWW
- Flamengo: 74.6 projected pts; top4 99.6%; top6 100.0%; top8 100.0%; relegation 0.0%; last5 DDWWD
- Bahia: 62.8 projected pts; top4 57.9%; top6 84.2%; top8 94.9%; relegation 0.0%; last5 DDWLW
- São Paulo: 62.1 projected pts; top4 57.4%; top6 84.8%; top8 96.0%; relegation 0.0%; last5 WDWLL
- Corinthians: 59.9 projected pts; top4 34.8%; top6 66.8%; top8 86.7%; relegation 0.0%; last5 DDWWW
- Cruzeiro: 57.4 projected pts; top4 18.4%; top6 48.0%; top8 74.3%; relegation 0.0%; last5 DDWDW
- Fluminense: 55.9 projected pts; top4 12.2%; top6 36.3%; top8 62.8%; relegation 0.1%; last5 WLWWD
- Vasco: 54.5 projected pts; top4 7.2%; top6 26.4%; top8 52.6%; relegation 0.3%; last5 DWLDW
- Botafogo: 54.4 projected pts; top4 6.7%; top6 24.4%; top8 51.4%; relegation 0.1%; last5 WWLDL
- Bragantino: 52.3 projected pts; top4 4.1%; top6 16.1%; top8 37.1%; relegation 1.0%; last5 DWLDW
- Atlético-MG: 50.5 projected pts; top4 1.4%; top6 7.3%; top8 20.4%; relegation 2.2%; last5 LLWLL
- Athletico-PR: 47.3 projected pts; top4 0.2%; top6 2.1%; top8 8.0%; relegation 11.4%; last5 DDWWD
- Vitória: 46.2 projected pts; top4 0.2%; top6 1.3%; top8 4.7%; relegation 16.5%; last5 DLWLW
- Santos: 46.0 projected pts; top4 0.1%; top6 0.9%; top8 4.5%; relegation 16.1%; last5 LWDWL
- Ceará: 45.6 projected pts; top4 0.1%; top6 0.6%; top8 3.4%; relegation 20.0%; last5 DWLLL
- Fortaleza: 45.0 projected pts; top4 0.1%; top6 0.7%; top8 2.8%; relegation 23.0%; last5 DDDLD
- Coritiba: 41.9 projected pts; top4 0.0%; top6 0.0%; top8 0.4%; relegation 49.8%; last5 LDLDL
- Goiás: 36.8 projected pts; top4 0.0%; top6 0.0%; top8 0.0%; relegation 81.7%; last5 DLLLL
- Mirassol: 35.6 projected pts; top4 0.0%; top6 0.0%; top8 0.0%; relegation 88.8%; last5 DLLWW
- Sport: 35.3 projected pts; top4 0.0%; top6 0.0%; top8 0.0%; relegation 89.2%; last5 DDLDL

## Audit
- 240 of 380 league fixtures completed, 140 scheduled
- No past fixtures/ledger/transfers rewritten
- 96 Libertadores groups; 96 Sudamericana groups; CDB legs unchanged
- Training sessions marked completed; one transient +0.50 strength applied pre-match and reverted; underlying player OVR unchanged
- Random Monte Carlo future simulations NOT written to canon DB