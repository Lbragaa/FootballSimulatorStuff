# THE BRAGA ERA · COPA LIBERTADORES 2027

## Administrative simulation checkpoint 037L (not a Vasco match)

Fictional retrospective season. Canonical starting point: Save 037 dated 2027-08-12. Entire 96-game Libertadores group phase simulated without rerolls, using 9 existing Brazil qualifiers and 23 fictional continental qualifiers, in 8 groups of 4.

### Draw & season logic
- Palmeiras won fictional Libertadores 2026; Atlético-MG won fictional Sudamericana 2026. Their continental qualifications remain intact.
- Nine Brazilian 2027 Libertadores qualifiers are preserved from `continental_qualifications`; these are not the actual real-world 2027 entrants.
- Group B has Atlético-MG and Bragantino because nine Brazilian teams are divided into eight groups. This is an explicit alternative-history deviation from the normal same-country protection.
- Groups are from four strength-ranked pots with stable seeded randomized placements. Non-Brazil club selection is fictional and no team overlaps the simulated Sudamericana group stage.
- All non-Brazil participants use club-strength proxies; no false individual players or match event narratives were synthesized.
- Six matches per club, home and away, with seeded Poisson finishing and modelled xG. Higher ground advantage applies moderately in La Paz.
- Group rankings: points, GD, goals scored, wins, alphabetical fallback. Matches played retrospectively on six fictional dates April 6 to May 25; existing league/Sula/Copa and Vasco player fitness remain unchanged.
- First two in each group enter Libertadores R16; third enters Sula knockout playoffs; fourth eliminated. R16 two-legged ties drawn winners vs runners-up; group winners host return leg.
- The actual CONMEBOL 2026 rules permit same-group R16 rematches, so the seeded random R16 draw can produce them. No pairings were rerolled to avoid rematches.
- Libertadores R16 Aug31/Sep7 and Sula playoffs Aug26/Sep2 are **provisional** pending multi-competition calendar reconciliation.

## All final group tables

| Group | # | Club | W | D | L | GF | GA | GD | Pts | Route |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---|
| A | 1 | Fluminense | 3 | 3 | 0 | 5 | 1 | +4 | **12** | R16 |
| A | 2 | Junior de Barranquilla | 2 | 2 | 2 | 5 | 4 | +1 | **8** | R16 |
| A | 3 | Platense | 1 | 3 | 2 | 3 | 4 | -1 | **6** | Sula playoff |
| A | 4 | El Nacional | 1 | 2 | 3 | 4 | 8 | -4 | **5** | Out |
| B | 1 | River Plate | 3 | 2 | 1 | 11 | 8 | +3 | **11** | R16 |
| B | 2 | Atlético-MG | 3 | 0 | 3 | 10 | 7 | +3 | **9** | R16 |
| B | 3 | Bragantino | 2 | 2 | 2 | 11 | 10 | +1 | **8** | Sula playoff |
| B | 4 | Deportivo Táchira | 1 | 2 | 3 | 6 | 13 | -7 | **5** | Out |
| C | 1 | Flamengo | 3 | 2 | 1 | 10 | 6 | +4 | **11** | R16 |
| C | 2 | Atlético Nacional | 3 | 2 | 1 | 12 | 11 | +1 | **11** | R16 |
| C | 3 | Newell's Old Boys | 3 | 0 | 3 | 12 | 12 | +0 | **9** | Sula playoff |
| C | 4 | Danubio | 0 | 2 | 4 | 4 | 9 | -5 | **2** | Out |
| D | 1 | Palmeiras | 4 | 1 | 1 | 13 | 7 | +6 | **13** | R16 |
| D | 2 | Bolívar | 3 | 2 | 1 | 11 | 6 | +5 | **11** | R16 |
| D | 3 | Sporting Cristal | 2 | 1 | 3 | 6 | 12 | -6 | **7** | Sula playoff |
| D | 4 | 2 de Mayo | 1 | 0 | 5 | 5 | 10 | -5 | **3** | Out |
| E | 1 | Santos | 5 | 0 | 1 | 15 | 12 | +3 | **15** | R16 |
| E | 2 | Estudiantes | 4 | 1 | 1 | 19 | 10 | +9 | **13** | R16 |
| E | 3 | Caracas FC | 1 | 1 | 4 | 7 | 14 | -7 | **4** | Sula playoff |
| E | 4 | Aucas | 1 | 0 | 5 | 4 | 9 | -5 | **3** | Out |
| F | 1 | Vélez Sarsfield | 2 | 3 | 1 | 8 | 6 | +2 | **9** | R16 |
| F | 2 | O'Higgins | 2 | 2 | 2 | 9 | 11 | -2 | **8** | R16 |
| F | 3 | Universitario | 2 | 2 | 2 | 7 | 9 | -2 | **8** | Sula playoff |
| F | 4 | Bahia | 2 | 1 | 3 | 10 | 8 | +2 | **7** | Out |
| G | 1 | Sportivo Luqueño | 4 | 2 | 0 | 7 | 3 | +4 | **14** | R16 |
| G | 2 | The Strongest | 2 | 1 | 3 | 7 | 6 | +1 | **7** | R16 |
| G | 3 | Athletico-PR | 2 | 1 | 3 | 7 | 7 | +0 | **7** | Sula playoff |
| G | 4 | Boca Juniors | 0 | 4 | 2 | 5 | 10 | -5 | **4** | Out |
| H | 1 | Liverpool (URU) | 4 | 0 | 2 | 13 | 8 | +5 | **12** | R16 |
| H | 2 | Huachipato | 3 | 2 | 1 | 8 | 7 | +1 | **11** | R16 |
| H | 3 | Rosario Central | 2 | 1 | 3 | 12 | 9 | +3 | **7** | Sula playoff |
| H | 4 | Cruzeiro | 1 | 1 | 4 | 7 | 16 | -9 | **4** | Out |

## Libertadores 2027 round of 16 — DRAWN, NOT PLAYED

| Tie | First leg | Return leg | Status |
|---|---|---|---|
| LIB-R16-01 | Bolívar vs Palmeiras | Palmeiras vs Bolívar | Scheduled, date provisional |
| LIB-R16-02 | Junior de Barranquilla vs Fluminense | Fluminense vs Junior de Barranquilla | Scheduled, date provisional |
| LIB-R16-03 | O'Higgins vs Vélez Sarsfield | Vélez Sarsfield vs O'Higgins | Scheduled, date provisional |
| LIB-R16-04 | Atlético-MG vs River Plate | River Plate vs Atlético-MG | Scheduled, date provisional |
| LIB-R16-05 | Estudiantes vs Santos | Santos vs Estudiantes | Scheduled, date provisional |
| LIB-R16-06 | Huachipato vs Flamengo | Flamengo vs Huachipato | Scheduled, date provisional |
| LIB-R16-07 | The Strongest vs Liverpool (URU) | Liverpool (URU) vs The Strongest | Scheduled, date provisional |
| LIB-R16-08 | Atlético Nacional vs Sportivo Luqueño | Sportivo Luqueño vs Atlético Nacional | Scheduled, date provisional |

## Sudamericana 2027 knockout play-offs — PREPARED, NOT PLAYED

| Tie | First leg | Return leg | Status |
|---|---|---|---|
| SULA-PO-01 | Caracas FC vs San Lorenzo | San Lorenzo vs Caracas FC | Scheduled, date provisional |
| SULA-PO-02 | Platense vs Emelec | Emelec vs Platense | Scheduled, date provisional |
| SULA-PO-03 | Sporting Cristal vs São Paulo | São Paulo vs Sporting Cristal | Scheduled, date provisional |
| SULA-PO-04 | Athletico-PR vs Peñarol | Peñarol vs Athletico-PR | Scheduled, date provisional |
| SULA-PO-05 | Rosario Central vs Libertad | Libertad vs Rosario Central | Scheduled, date provisional |
| SULA-PO-06 | Universitario vs Universidad Católica | Universidad Católica vs Universitario | Scheduled, date provisional |
| SULA-PO-07 | Bragantino vs Independiente | Independiente vs Bragantino | Scheduled, date provisional |
| SULA-PO-08 | Newell's Old Boys vs Botafogo | Botafogo vs Newell's Old Boys | Scheduled, date provisional |

## Complete Libertadores group-stage results — 96 matches

| MD | Group | Home | Score | Away | Home xG | Away xG |
|---:|---|---|---:|---|---:|---:|
| 1 | A | Fluminense | 2–1 | El Nacional | 2.01 | 1.14 |
| 1 | A | Junior de Barranquilla | 2–0 | Platense | 1.27 | 1.12 |
| 1 | B | Atlético-MG | 2–0 | Bragantino | 1.47 | 1.09 |
| 1 | B | River Plate | 2–2 | Deportivo Táchira | 1.79 | 0.62 |
| 1 | C | Atlético Nacional | 1–4 | Newell's Old Boys | 1.28 | 1.04 |
| 1 | C | Flamengo | 2–1 | Danubio | 1.73 | 0.52 |
| 1 | D | Bolívar | 4–1 | Sporting Cristal | 1.75 | 0.71 |
| 1 | D | Palmeiras | 1–0 | 2 de Mayo | 1.56 | 0.47 |
| 1 | E | Estudiantes | 4–1 | Caracas FC | 2.01 | 0.95 |
| 1 | E | Santos | 2–1 | Aucas | 1.39 | 0.83 |
| 1 | F | Bahia | 0–0 | Universitario | 0.54 | 0.91 |
| 1 | F | Vélez Sarsfield | 1–1 | O'Higgins | 1.53 | 0.89 |
| 1 | G | Athletico-PR | 3–1 | The Strongest | 1.53 | 1.26 |
| 1 | G | Boca Juniors | 1–1 | Sportivo Luqueño | 1.61 | 0.45 |
| 1 | H | Cruzeiro | 1–3 | Liverpool (URU) | 1.57 | 1.23 |
| 1 | H | Rosario Central | 1–1 | Huachipato | 1.69 | 0.65 |
| 2 | A | El Nacional | 1–1 | Junior de Barranquilla | 1.09 | 1.47 |
| 2 | A | Platense | 0–0 | Fluminense | 0.86 | 1.21 |
| 2 | B | Bragantino | 2–2 | River Plate | 0.95 | 1.36 |
| 2 | B | Deportivo Táchira | 2–1 | Atlético-MG | 0.93 | 1.46 |
| 2 | C | Danubio | 1–3 | Atlético Nacional | 1.03 | 1.11 |
| 2 | C | Newell's Old Boys | 0–3 | Flamengo | 1.00 | 1.51 |
| 2 | D | 2 de Mayo | 0–1 | Bolívar | 1.35 | 1.32 |
| 2 | D | Sporting Cristal | 1–3 | Palmeiras | 1.29 | 1.53 |
| 2 | E | Aucas | 0–2 | Estudiantes | 1.24 | 1.26 |
| 2 | E | Caracas FC | 1–3 | Santos | 1.27 | 1.42 |
| 2 | F | O'Higgins | 4–2 | Bahia | 1.22 | 1.60 |
| 2 | F | Universitario | 2–2 | Vélez Sarsfield | 1.22 | 1.11 |
| 2 | G | Sportivo Luqueño | 2–1 | Athletico-PR | 0.82 | 1.29 |
| 2 | G | The Strongest | 4–0 | Boca Juniors | 1.54 | 0.86 |
| 2 | H | Huachipato | 3–2 | Cruzeiro | 1.21 | 1.21 |
| 2 | H | Liverpool (URU) | 4–1 | Rosario Central | 1.27 | 1.21 |
| 3 | A | Fluminense | 2–0 | Junior de Barranquilla | 1.59 | 0.63 |
| 3 | A | Platense | 1–2 | El Nacional | 1.55 | 1.42 |
| 3 | B | Bragantino | 5–1 | Deportivo Táchira | 1.37 | 0.75 |
| 3 | B | River Plate | 2–0 | Atlético-MG | 1.77 | 0.61 |
| 3 | C | Flamengo | 0–0 | Atlético Nacional | 1.57 | 0.77 |
| 3 | C | Newell's Old Boys | 1–0 | Danubio | 1.33 | 0.78 |
| 3 | D | Palmeiras | 2–2 | Bolívar | 1.42 | 0.59 |
| 3 | D | Sporting Cristal | 2–1 | 2 de Mayo | 1.65 | 0.65 |
| 3 | E | Aucas | 1–0 | Caracas FC | 1.68 | 1.05 |
| 3 | E | Estudiantes | 7–3 | Santos | 1.54 | 0.94 |
| 3 | F | Universitario | 1–0 | O'Higgins | 1.22 | 1.19 |
| 3 | F | Vélez Sarsfield | 0–2 | Bahia | 1.20 | 1.04 |
| 3 | G | Boca Juniors | 1–2 | Athletico-PR | 1.91 | 1.09 |
| 3 | G | The Strongest | 0–1 | Sportivo Luqueño | 1.62 | 1.03 |
| 3 | H | Cruzeiro | 2–1 | Rosario Central | 1.54 | 0.98 |
| 3 | H | Huachipato | 1–0 | Liverpool (URU) | 1.48 | 0.77 |
| 4 | A | El Nacional | 0–0 | Fluminense | 0.96 | 1.21 |
| 4 | A | Platense | 0–0 | Junior de Barranquilla | 1.06 | 0.92 |
| 4 | B | Bragantino | 3–1 | Atlético-MG | 1.11 | 1.61 |
| 4 | B | Deportivo Táchira | 0–2 | River Plate | 1.21 | 1.72 |
| 4 | C | Danubio | 1–1 | Flamengo | 0.68 | 1.47 |
| 4 | C | Newell's Old Boys | 4–5 | Atlético Nacional | 1.49 | 1.05 |
| 4 | D | 2 de Mayo | 1–3 | Palmeiras | 0.32 | 1.38 |
| 4 | D | Sporting Cristal | 0–0 | Bolívar | 1.19 | 0.99 |
| 4 | E | Aucas | 0–1 | Santos | 1.25 | 1.54 |
| 4 | E | Caracas FC | 2–2 | Estudiantes | 1.11 | 1.47 |
| 4 | F | O'Higgins | 1–1 | Vélez Sarsfield | 1.08 | 1.51 |
| 4 | F | Universitario | 3–1 | Bahia | 1.00 | 1.42 |
| 4 | G | Sportivo Luqueño | 1–1 | Boca Juniors | 1.37 | 1.34 |
| 4 | G | The Strongest | 1–0 | Athletico-PR | 1.07 | 0.72 |
| 4 | H | Huachipato | 1–0 | Rosario Central | 1.13 | 1.11 |
| 4 | H | Liverpool (URU) | 2–1 | Cruzeiro | 1.10 | 1.28 |
| 5 | A | Fluminense | 0–0 | Platense | 1.34 | 0.48 |
| 5 | A | Junior de Barranquilla | 2–0 | El Nacional | 1.34 | 0.82 |
| 5 | B | Atlético-MG | 2–0 | Deportivo Táchira | 1.85 | 0.67 |
| 5 | B | River Plate | 3–0 | Bragantino | 1.93 | 0.65 |
| 5 | C | Atlético Nacional | 0–0 | Danubio | 1.23 | 1.26 |
| 5 | C | Flamengo | 2–1 | Newell's Old Boys | 1.85 | 0.73 |
| 5 | D | Bolívar | 2–3 | 2 de Mayo | 1.57 | 0.82 |
| 5 | D | Palmeiras | 4–1 | Sporting Cristal | 1.93 | 0.89 |
| 5 | E | Estudiantes | 2–1 | Aucas | 1.76 | 0.95 |
| 5 | E | Santos | 3–1 | Caracas FC | 1.68 | 0.84 |
| 5 | F | Bahia | 5–0 | O'Higgins | 1.99 | 1.28 |
| 5 | F | Vélez Sarsfield | 3–0 | Universitario | 1.95 | 1.10 |
| 5 | G | Athletico-PR | 0–1 | Sportivo Luqueño | 1.44 | 1.07 |
| 5 | G | Boca Juniors | 1–1 | The Strongest | 1.69 | 0.67 |
| 5 | H | Cruzeiro | 1–1 | Huachipato | 1.07 | 0.57 |
| 5 | H | Rosario Central | 3–1 | Liverpool (URU) | 1.31 | 0.86 |
| 6 | A | El Nacional | 0–2 | Platense | 1.34 | 1.03 |
| 6 | A | Junior de Barranquilla | 0–1 | Fluminense | 1.46 | 1.54 |
| 6 | B | Atlético-MG | 4–0 | River Plate | 1.01 | 1.18 |
| 6 | B | Deportivo Táchira | 1–1 | Bragantino | 1.24 | 0.73 |
| 6 | C | Atlético Nacional | 3–2 | Flamengo | 1.10 | 1.20 |
| 6 | C | Danubio | 1–2 | Newell's Old Boys | 1.29 | 1.14 |
| 6 | D | 2 de Mayo | 0–1 | Sporting Cristal | 1.74 | 1.22 |
| 6 | D | Bolívar | 2–0 | Palmeiras | 1.55 | 1.44 |
| 6 | E | Caracas FC | 2–1 | Aucas | 1.27 | 1.20 |
| 6 | E | Santos | 3–2 | Estudiantes | 1.08 | 1.58 |
| 6 | F | Bahia | 0–1 | Vélez Sarsfield | 1.05 | 0.96 |
| 6 | F | O'Higgins | 3–1 | Universitario | 0.95 | 1.35 |
| 6 | G | Athletico-PR | 1–1 | Boca Juniors | 1.04 | 1.31 |
| 6 | G | Sportivo Luqueño | 1–0 | The Strongest | 1.60 | 0.79 |
| 6 | H | Liverpool (URU) | 3–1 | Huachipato | 1.08 | 1.00 |
| 6 | H | Rosario Central | 6–0 | Cruzeiro | 1.39 | 0.77 |

## Historical protection & integrity

- Source check: all rows in original `clubs`, `players`, `fixtures`, `events`, `shots`, `player_matches`, `finance_ledger`, original Sula fixture/standings and outcomes, Copa do Brasil and player form tables compared; all identical.
- 180 previous 2027 Brasileirão games, 96 Sula games and 32 Copa do Brasil fifth-phase games unchanged.
- `meta.current_date` remains 2027-08-12 23:30. `next_match_fixture` remains 2027-08-15 Vasco vs Athletico-PR.
- Original financial ledger unchanged; R$38.64m football cash and previous July wage booking preserved.
- Savarino Fluminense current #354 and Botafogo archived #196 remain untouched.
- The group matches are a **retrospective fictional simulation**, not contemporaneously integrated into Brazilian squad fitness. Future Brazilian cross-competition fatigue should incorporate subsequent Libertadores knockout matches when they are played.

## Format reference
The CONMEBOL 2026 group stage format (8 groups x 4, two legs per opponent, 2 R16 qualifiers and third to Sudamericana playoff) is used as a structural reference; the 2027 teams/results are entirely fictional: https://gol.conmebol.com/libertadores/en/news/sorteo-de-la-fase-de-grupos-de-la-conmebol-libertadores-2026-fecha-horario-clasificados
