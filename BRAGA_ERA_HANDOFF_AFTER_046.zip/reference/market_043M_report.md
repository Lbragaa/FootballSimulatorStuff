# THE BRAGA ERA — SAVE 043M · MERCADO DE 2027

**Data canônica:** 3 September 2027. All transfers below FICTIONAL, negotiated inside the alternate-history football universe, not reports of actual transfers. Real-world 2026 market coverage informed only fee scales, loan frequency and negotiation practices.

## Completed Vasco deals

1. **Arthur Dias**, 75 OVR defender, Athletico-PR → Vasco, **R$13.2m**, monthly wage **R$265k** (annual R$3.18m), agent fee **R$720k**, signed September 1 through December 2030. Athletico declined R$10.5m and R$12m amid relegation fight; accepted premium.
2. **Álvaro Barreal**, 73 OVR attacking midfielder/winger, Santos → Vasco, **R$5.4m**, monthly wage **R$160k** (annual R$1.92m), agent **R$390k**, signed September 2 through December 2029. A R$4.7m opening offer was countered.

**Important:** neither signing guarantees improved defensive results; engine must use them with ratings/fitness/competition as any other player. Current historical apps and stats remain attributed to original clubs; only future eligibility shifts. No fabricated appearances.

## Other completed Serie A transfers

- Maurício (Palmeiras → Ceará) R$4.8m, R$145k/month.
- Erick Pulgar (Flamengo → Grêmio) R$5.9m, R$220k/month.
- Walace (Vitória → Coritiba) R$2.3m, R$125k/month.
- Tomás Pérez (Atlético-MG → Goiás) R$2.6m, R$130k/month.

Each deal is simulated and affects only future rosters; SAF books are NOT charged for other clubs' transfers.

## Vasco finances

- Original 042M available acquisition fees: R$20.0m. Completed fees R$18.6m; **remaining R$1.4m**.
- Previous annual incremental wage room R$5.44m. New annual commitments R$5.10m; **remaining R$0.34m**.
- Previous scouting/agent room R$3.30m. Paid agent fees R$1.11m; **remaining R$2.19m**.
- Restricted cash: **R$31.93m** (R$51.64m less acquisition fees and agent fees); future wages paid on future paydays only, not double-debited now.
- Emergency reserve remains untouched, R$16m; no new SAF capital injected.

## Integrity

210 of 380 league matches completed. All previous match logs, 2027 Copa do Brasil, 96 Libertadores group matches and 96 Sul-Americana group matches unchanged. No new competitive games played. Next match: September 5 São Paulo vs Vasco, Brasileirão R22.
