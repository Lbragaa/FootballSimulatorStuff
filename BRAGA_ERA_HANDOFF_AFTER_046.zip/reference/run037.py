from pathlib import Path
import sqlite3,random,math,hashlib,shutil,json,collections
B=Path('/mnt/data/Braga_Era');P=B/'work037';P.mkdir(exist_ok=True);src=B/'tmp036/Save036/braga_save.sqlite';dst=P/'braga_save.sqlite';shutil.copy2(src,dst)
c=sqlite3.connect(dst);c.row_factory=sqlite3.Row
old={r['id']:tuple(r) for r in c.execute("select * from fixtures where status='final'")};old_sula={r['id']:tuple(r) for r in c.execute("select * from sudamericana_2027_fixtures where status='final'")};old_cup=[tuple(r) for r in c.execute("select * from copa_do_brasil_2027_fixtures")] if c.execute("select count(*) from sqlite_master where type='table' and name='copa_do_brasil_2027_fixtures'").fetchone()[0] else None;ledger=[tuple(r) for r in c.execute('select * from finance_ledger')]
assert c.execute("select value from meta where key='saved_state_version'").fetchone()[0]=='036'
c.executescript('''CREATE TABLE IF NOT EXISTS continental_match_events(id INTEGER PRIMARY KEY AUTOINCREMENT, fixture_id INTEGER, minute INTEGER, team TEXT, player TEXT, type TEXT, xg REAL, detail TEXT);
CREATE TABLE IF NOT EXISTS continental_match_shots(id INTEGER PRIMARY KEY AUTOINCREMENT, fixture_id INTEGER, minute INTEGER, team TEXT, player TEXT, xg REAL, on_target INTEGER, goal INTEGER);
CREATE TABLE IF NOT EXISTS continental_player_matches(fixture_id INTEGER, player_id INTEGER, club TEXT, started INTEGER, minutes INTEGER, goals INTEGER, assists INTEGER, shots INTEGER, xg REAL, rating REAL, PRIMARY KEY(fixture_id,player_id));
CREATE TABLE IF NOT EXISTS continental_match_audit(fixture_id INTEGER PRIMARY KEY, seed INTEGER, strength_home REAL, strength_away REAL, planned_xg_home REAL, planned_xg_away REAL, tactical_plan TEXT);
''')
c.execute("update players set fitness=min(100,fitness+3) where injury is null or injury=''")
clubs={r['name']:dict(r) for r in c.execute('select * from clubs')}
foreign_strength={'San Lorenzo':73,'Millonarios':72.5,'América de Cali':70.5,'Nacional (URU)':74,'Huracán':72,'Defensor Sporting':69,'Cerro Porteño':72.5,'Olimpia':73,'Universidad de Chile':73,'Argentinos Juniors':75,'Colo-Colo':74,'Emelec':70.5,'Universidad Católica':72,'Defensa y Justicia':72,'Barcelona SC':72,'Palestino':70.5,'Peñarol':75.5,'Audax Italiano':70,'Guaraní':71,'Independiente':76,'Independiente del Valle':77,'Racing Club':78,'LDU Quito':76.5,'Talleres':74,'Libertad':74.5,'Lanús':76}
def get_strength(t):return clubs[t]['strength'] if t in clubs else foreign_strength.get(t,72)
def clamp(x,a,b):return max(a,min(b,x))
def weighted(rng,ps,fn):return rng.choices(ps,weights=[max(.1,fn(p)) for p in ps])[0]
def form(p):
 r=c.execute('select form_rating from match_form_profile where player_id=?',(p['id'],)).fetchone();return float(r[0]) if r else 6.55
def lineup(name):
 if name not in clubs:return [],[]
 ps=[dict(r) for r in c.execute('select * from players where club_id=? and (injury is null or injury="") and id not in (select archived_id from player_identity_resolution)',(clubs[name]['id'],))]
 if name=='Vasco':
  names=['Léo Jardim','Paulo Henrique','Alan Saldivia','Robert Renan','Cuiabano','Santiago Sosa','Rodrigo Villagra','Andrés Gómez','Alan Lescano','Nuno Moreira','Bruno Duarte'];out=[next(p for p in ps if p['name']==n) for n in names]
 else:
  out=[]
  for role,num in [('GK',1),('DF',4),('MF',3),('FW',3)]:out+=sorted([p for p in ps if p['pos']==role and p not in out],key=lambda p:p['ovr']+2*(form(p)-6.55)+p['fitness']*.04,reverse=True)[:num]
  out+=sorted([p for p in ps if p not in out],key=lambda p:p['ovr'],reverse=True)[:11-len(out)]
 return out,[p for p in ps if p not in out]
fixtures=[dict(r) for r in c.execute('select * from sudamericana_2027_fixtures where matchday=6 and status="scheduled" order by group_id,id')]
assert len(fixtures)==16
results=[]
for fix in fixtures:
 fid=fix['id'];home=fix['home'];away=fix['away'];rng=random.Random(int.from_bytes(hashlib.sha256(f'Braga-CONMEBOL-2027-MD6-{fid}-v1'.encode()).digest()[:8],'big'))
 hxi,hbench=lineup(home);axi,abench=lineup(away)
 hqual=get_strength(home)+(.22*sum(form(p)-6.55 for p in hxi)/len(hxi)-.028*sum(100-p['fitness'] for p in hxi)/len(hxi) if hxi else 0);aqual=get_strength(away)+(.22*sum(form(p)-6.55 for p in axi)/len(axi)-.028*sum(100-p['fitness'] for p in axi)/len(axi) if axi else 0)
 homebase=clamp(1.52+.062*(hqual-aqual),.48,2.65);awaybase=clamp(1.12+.062*(aqual-hqual),.42,2.45)
 if away=='Vasco' and home=='Millonarios':
  # 2,640m Bogota altitude, away squad non-acclimatized: reduced chance creation and transition energy
  awaybase*=.89;homebase*=1.045
 if home=='Vasco':homebase+=.09;awaybase-=.04
 if away=='Vasco':awaybase+=.08;homebase-=.02
 # Mild opponent chance boost when visiting defence is fatigued, no score targeting
 if away=='Vasco':homebase+=.012*sum(100-p['fitness'] for p in axi)/len(axi)
 shots=[];events=[];act={home:list(hxi),away:list(axi)};benches={home:hbench,away:abench};part={p['id']:dict(started=1,minutes=90,goals=0,assists=0,shots=0,xg=0,club=team) for team,xi in ((home,hxi),(away,axi)) for p in xi}
 for team,lam in [(home,homebase),(away,awaybase)]:
  num=max(6,min(21,round(rng.gauss(11.0+(get_strength(team)-72)*.06,2.5))))
  raw=[clamp(rng.betavariate(1.35,10),.01,.52) for _ in range(num)];scale=lam/sum(raw)
  for x in raw:shots.append(dict(minute=rng.randint(2,95),team=team,xg=round(clamp(x*scale,.012,.68),4)))
 timeline=[(s['minute'],2,'SHOT',s) for s in shots]
 for team in [home,away]:
  if team in clubs:
   for minute in ([62,75,84] if team=='Vasco' else [65,79]):timeline.append((minute,1,'SUB',{'team':team}))
 timeline.sort(key=lambda s:(s[0],s[1]));score={home:0,away:0};shotlog=[];subs=[]
 for minute,_,kind,s in timeline:
  team=s['team']
  if kind=='SUB':
   scoreopp=score[away if team==home else home];trailing=score[team]<scoreopp
   if team=='Vasco':
    if score[team] > scoreopp:
     order=[('Andrés Gómez','Facundo Colidio'),('Rodrigo Villagra','Thiago Mendes'),('Santiago Sosa','Cauan Barros')]
    elif trailing:
     order=[('Nuno Moreira','Facundo Colidio'),('Andrés Gómez','Carlos Vinícius'),('Santiago Sosa','Thiago Mendes')]
    else:
     order=[('Nuno Moreira','Facundo Colidio'),('Andrés Gómez','Carlos Vinícius'),('Santiago Sosa','Thiago Mendes')]
    selected=None
    for o,n in order:
     oldp=next((p for p in act[team] if p['name']==o and part[p['id']]['started']==1),None);newp=next((p for p in benches[team] if p['name']==n),None)
     if oldp and newp:selected=(oldp,newp);break
   else:
    selected=None
    for role in (['FW','MF','DF'] if trailing else ['MF','DF','FW']):
     outs=[p for p in act[team] if p['pos']==role and part[p['id']]['started']==1];ins=[p for p in benches[team] if p['pos']==role]
     if outs and ins:selected=(min(outs,key=lambda p:p['fitness']),max(ins,key=lambda p:p['ovr']+form(p)));break
   if selected:
    o,n=selected;act[team].remove(o);act[team].append(n);benches[team].remove(n);part[o['id']]['minutes']=minute;part[n['id']]=dict(started=0,minutes=90-minute,goals=0,assists=0,shots=0,xg=0,club=team)
    events.append(dict(minute=minute,team=team,player=n['name'],type='SUB',xg=0,detail='replaces '+o['name']));subs.append((minute,team,o['name'],n['name']))
   continue
  squad=act[team]
  if squad:
   shooter=weighted(rng,[p for p in squad if p['pos']!='GK'],lambda p:({'FW':5.0,'MF':2.6,'DF':.55}[p['pos']])*(p['attack']/73)**2*(1+.11*(form(p)-6.55)))
   player=shooter['name'];skill=clamp(1+.11*(form(shooter)-6.55)+.003*(shooter['attack']-74)+.002*(shooter['fitness']-90),.77,1.22)
  else:shooter=None;player=weighted(rng,['Forward','Attacking midfielder','Winger','Centre-back'],lambda x:{'Forward':6,'Attacking midfielder':4,'Winger':4,'Centre-back':1}[x]);skill=1
  xg=s['xg'];goal=int(rng.random()<clamp(xg*skill,.006,.72));on=int(goal or rng.random()<clamp(.27+xg*.70,.25,.7));shotlog.append((minute,team,player,xg,on,goal))
  if shooter:
   part[shooter['id']]['shots']+=1;part[shooter['id']]['xg']+=xg;part[shooter['id']]['goals']+=goal
  if goal:
   score[team]+=1;assister=None
   if rng.random()<.75:
    if squad:
     others=[p for p in squad if p['id']!=shooter['id']];assister=weighted(rng,others,lambda p:{'GK':.03,'DF':.7,'MF':3.1,'FW':2.0}[p['pos']]*p['passing']/72)
     part[assister['id']]['assists']+=1;assister=assister['name']
    else:assister=rng.choice(['Attacking midfielder','Winger','Fullback'])
   events.append(dict(minute=minute,team=team,player=player,type='GOAL',xg=xg,detail=('assist: '+assister) if assister else 'unassisted'))
 hxg=round(sum(s[3] for s in shotlog if s[1]==home),2);axg=round(sum(s[3] for s in shotlog if s[1]==away),2)
 c.execute("update sudamericana_2027_fixtures set status='final',hg=?,ag=?,home_xg=?,away_xg=? where id=?",(score[home],score[away],hxg,axg,fid))
 for team,op in [(home,away),(away,home)]:
  c.execute('update sudamericana_2027_groups set played=played+1,points=points+?,gf=gf+?,ga=ga+? where group_id=? and club=?',(3 if score[team]>score[op] else 1 if score[team]==score[op] else 0,score[team],score[op],fix['group_id'],team))
 for e in events:c.execute('insert into continental_match_events(fixture_id,minute,team,player,type,xg,detail) values(?,?,?,?,?,?,?)',(fid,*[e[k] for k in ['minute','team','player','type','xg','detail']]))
 for sh in shotlog:c.execute('insert into continental_match_shots(fixture_id,minute,team,player,xg,on_target,goal) values(?,?,?,?,?,?,?)',(fid,*sh))
 for pid,st in part.items():
  p=c.execute('select * from players where id=?',(pid,)).fetchone();win=score[st['club']]>score[away if st['club']==home else home];draw=score[home]==score[away]
  rating=round(clamp(6.42+.035*(p['ovr']-72)+.16*(form(p)-6.55)+st['goals']*.88+st['assists']*.55+(.19 if win else .03 if draw else -.16),5.5,9.4),1)
  c.execute('insert into continental_player_matches values(?,?,?,?,?,?,?,?,?,?)',(fid,pid,st['club'],st['started'],st['minutes'],st['goals'],st['assists'],st['shots'],round(st['xg'],3),rating))
  c.execute('''insert into player_season_totals(season,competition,player_id,club_id,apps,minutes,goals,assists,shots,xg,rating_sum) values(2027,'Sul-Americana 2027',?,?,?,?,?,?,?,?,?) on conflict(season,competition,player_id) do update set apps=apps+1,minutes=minutes+excluded.minutes,goals=goals+excluded.goals,assists=assists+excluded.assists,shots=shots+excluded.shots,xg=xg+excluded.xg,rating_sum=rating_sum+excluded.rating_sum''',(pid,p['club_id'],1,st['minutes'],st['goals'],st['assists'],st['shots'],round(st['xg'],3),rating))
  c.execute('update players set apps=apps+1,minutes=minutes+?,goals=goals+?,assists=assists+?,shots=shots+?,xg=xg+?,rating_total=rating_total+?,fitness=max(66,fitness-?),morale=min(100,max(30,morale+?)) where id=?',(st['minutes'],st['goals'],st['assists'],st['shots'],round(st['xg'],3),rating,rng.randint(3,7),2 if win else 0 if draw else -1,pid))
  existing=list(c.execute('select pm.rating,pm.minutes from player_matches pm join fixtures f on f.id=pm.fixture_id where pm.player_id=? and f.competition="Brasileirão 2027" order by f.id desc limit 3',(pid,)))
  values=[(rating,st['minutes'])]+[(x[0],x[1]) for x in existing];weights=[.7**i*min(1,m/60)**.5 for i,(_,m) in enumerate(values)];rating_form=round(6.55+(sum(w*r for w,(r,m) in zip(weights,values))/sum(weights)-6.55)*min(1,len(values)/3),3)
  c.execute('insert or replace into match_form_profile values(?,?,?)',(pid,rating_form,'2027-08-12'))
 c.execute('insert into continental_match_audit values(?,?,?,?,?,?,?)',(fid,int.from_bytes(hashlib.sha256(f'Braga-CONMEBOL-2027-MD6-{fid}-v1'.encode()).digest()[:8],'big')%(2**63),hqual,aqual,homebase,awaybase,'MD6 seeded shots, home familiarity, domestic form, injuries, fatigue; foreign virtual roles'))
 result=dict(fixture=fid,group=fix['group_id'],home=home,away=away,hg=score[home],ag=score[away],hxg=hxg,axg=axg,events=sorted(events,key=lambda e:e['minute']),subs=subs,shots=shotlog)
 results.append(result)
 if home=='Vasco' or away=='Vasco':
  c.execute("update meta set value=cast(cast(value as integer)+1 as text) where key='braga_matches'")
  oldconfidence=int(c.execute("select value from meta where key='board_confidence'").fetchone()[0]);outcome=3 if score['Vasco']>score[away if home=='Vasco' else home] else 0 if score['Vasco']==score[away if home=='Vasco' else home] else -2
  c.execute("update meta set value=? where key='board_confidence'",(str(clamp(oldconfidence+outcome,0,100)),))
  c.execute('insert into decisions(dated,category,decision,impact) values(?,?,?,?)',('2027-08-12','continental group stage','Braga maintains compact asymmetric 4-2-3-1; full focus on progression; monitors form and fatigue','America de Cali-Vasco Matchday 4, seeded independent shots; adjustments at minutes 62/75/84 according to score.'))
  c.execute('insert into news(dated,headline,body,type) values(?,?,?,?)',('2027-08-12',f'Sul-Americana: {home} {score[home]}-{score[away]} {away}',f'Group {fix["group_id"]} matchday six, xG {hxg}-{axg}','fictional'))
# No payroll this date; June wage installment already booked in Save030.
for k,v in [('saved_state_version','037'),('current_date','2027-08-12 23:30'),('next_match_fixture','2027-08-15 Vasco vs Athletico-PR Brasileirão R19; 2027-08-18 Fluminense vs Vasco Copa do Brasil R16 first leg'),('sudamericana_group_progress','MD6 complete: 96 of 96 group matches; final rankings confirmed; group leaders R16, runners-up playoffs')]:c.execute('insert or replace into meta values(?,?)',(k,v))
c.execute('insert or replace into meta values(?,?)',('brasileirao_calendar_status','R1-R18 complete, R19-R38 scheduled from Aug 15 through Dec 19; previous calendar fix preserved'))
# Persist frozen MD6 group positions and qualification without simulating playoff results.
c.execute("""create table if not exists sudamericana_2027_group_outcomes(group_id TEXT,position INTEGER,club TEXT,points INTEGER,gd INTEGER,gf INTEGER,route TEXT, PRIMARY KEY(group_id,position))""")
standings_final=[]
for gid in 'ABCDEFGH':
 rows=[dict(r) for r in c.execute('select group_id,club,points,played,gf,ga from sudamericana_2027_groups where group_id=?',(gid,))]
 rows.sort(key=lambda r:(-r['points'],-(r['gf']-r['ga']),-r['gf'],r['club']))
 assert len(rows)==4 and all(x['played']==6 for x in rows)
 for rank,r in enumerate(rows,1):
  route=('round_of_16' if rank==1 else 'knockout_playoff' if rank==2 else 'eliminated')
  c.execute('insert into sudamericana_2027_group_outcomes values(?,?,?,?,?,?,?)',(gid,rank,r['club'],r['points'],r['gf']-r['ga'],r['gf'],route))
  standings_final.append({'group':gid,'rank':rank,'club':r['club'],'points':r['points'],'gd':r['gf']-r['ga'],'gf':r['gf'],'route':route})
c.execute('insert into decisions(dated,category,decision,impact) values(?,?,?,?)',('2027-08-12','continental tournament','Finalized all eight Sudamericana groups using points, goal difference, goals for, name for exact tie; no knockout games simulated','Eight group winners directly into R16; eight runners-up to knockout playoffs, opponent from Libertadores yet to be allocated.'))
c.execute('insert or replace into meta values(?,?)',('sudamericana_group_tiebreak','Points; goal difference; goals scored; deterministic name fallback on complete tie; fictional tournament convention.'))
c.execute('insert or replace into meta values(?,?)',('sudamericana_knockout_state','8 group winners into Round of 16 and 8 runners-up awaiting playoff opponents; no knockout result generated.'))
# Book the overdue July incremental payroll exactly once (the previous canonical state omitted it).
if not c.execute("select 1 from finance_ledger where dated='2027-07-31' and category='incremental wage payroll'").fetchone():
 c.execute("""insert into finance_ledger(dated,category,account,amount_brl,restricted_for,description,fictional) values(?,?,?,?,?,?,?)""",('2027-07-31','incremental wage payroll','2027 football restricted account',-1380000.0,'Incremental wages','July 2027 payroll booked once; carried from overdue month; not a new annual wage authorization',1))
c.execute('insert or replace into meta values(?,?)',('july_2027_wage_status','paid once, dated 2027-07-31, R$1,380,000 debited'))
c.commit()
assert c.execute('pragma integrity_check').fetchone()[0]=='ok'
assert all(tuple(c.execute('select * from fixtures where id=?',(fid,)).fetchone())==prior for fid,prior in old.items())
assert [tuple(r) for r in c.execute('select * from finance_ledger order by id limit ?',(len(ledger),))]==ledger
assert c.execute("select count(*) from finance_ledger where dated='2027-07-31' and category='incremental wage payroll'").fetchone()[0]==1
assert all(tuple(c.execute('select * from sudamericana_2027_fixtures where id=?',(fid,)).fetchone())==prior for fid,prior in old_sula.items())
if old_cup is not None: assert old_cup==[tuple(r) for r in c.execute('select * from copa_do_brasil_2027_fixtures')]
assert c.execute("select count(*) from fixtures where competition='Brasileirão 2027' and status='final'").fetchone()[0]==180
assert c.execute("select count(*) from sudamericana_2027_fixtures where status='final'").fetchone()[0]==96
assert c.execute("select count(*) from sudamericana_2027_groups where played=6").fetchone()[0]==32
for r in results:
 assert r['hg']+r['ag']==sum(s[-1] for s in r['shots'])==sum(e['type']=='GOAL' for e in r['events'])
group=[dict(x) for x in c.execute('select * from sudamericana_2027_groups order by group_id,points desc,gf-ga desc,gf desc')]
vasco=next(r for r in results if r['home']=='Vasco' or r['away']=='Vasco')
vp=[dict(x) for x in c.execute('select p.name,cm.* from continental_player_matches cm join players p on p.id=cm.player_id where cm.fixture_id=? and cm.club="Vasco" order by cm.rating desc',(vasco['fixture'],))]
output={'advancement':standings_final,'vasco':vasco,'results':results,'groups':group,'vasco_players':vp,'confidence':c.execute("select value from meta where key='board_confidence'").fetchone()[0],'finance_cash':sum(x[0] for x in c.execute("select amount_brl from finance_ledger where account='2027 football restricted account'"))}
(P/'results037.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
print(json.dumps({'vasco':vasco,'other':[(r['home'],r['hg'],r['ag'],r['away']) for r in results],'confidence':output['confidence'],'cash':output['finance_cash']},ensure_ascii=False,indent=2))
c.close()
