from pathlib import Path
from datetime import date
import sqlite3, shutil, json, random, hashlib, math, collections, zipfile

B=Path('/mnt/data/Braga_Era'); src=B/'work037/braga_save.sqlite'; out=B/'work037L';out.mkdir(exist_ok=True)
dest=out/'braga_save.sqlite'
shutil.copy2(src,dest)
conn=sqlite3.connect(dest);conn.row_factory=sqlite3.Row
cur=conn.cursor()

def stable_seed(tag):return int.from_bytes(hashlib.sha256(('BRAGA_LIBERTADORES_2027_SAVE037L|'+str(tag)+'|seed=20261023').encode()).digest()[:8],'big')
def rng(tag):return random.Random(stable_seed(tag))
def poisson(r, lam):
    p=math.exp(-lam);v=1.;k=0
    while v>p:
        v*=r.random();k+=1
    return max(0,k-1)

def check(cond,msg):
 if not cond: raise ValueError(msg)

# 2026 fictional campaign's exact 2027 Libertadores qualifications in source DB.
bra=[r['club'] for r in conn.execute("select club from continental_qualifications where season=2027 and competition='Copa Libertadores' and status='clinched'")]
check(len(bra)==9,'Expected 9 canonical Brazilian qualifiers')
club_overall={r['name']:r['strength'] for r in conn.execute('select name,strength from clubs')}
others=[
 ('River Plate','ARG',80.0),('Boca Juniors','ARG',79.2),('Estudiantes','ARG',78.4),('Vélez Sarsfield','ARG',76.7),('Rosario Central','ARG',74.6),('Newell\'s Old Boys','ARG',72.5),('Platense','ARG',71.9),
 ('Liverpool (URU)','URU',71.2),('Danubio','URU',69.9),
 ('Sportivo Luqueño','PAR',70.3),('2 de Mayo','PAR',69.3),
 ('Aucas','ECU',73.5),('El Nacional','ECU',70.4),
 ('Atlético Nacional','COL',76.3),('Junior de Barranquilla','COL',74.2),
 ('Huachipato','CHI',71.9),("O'Higgins",'CHI',71.4),
 ('Universitario','PER',73.6),('Sporting Cristal','PER',72.4),
 ('Bolívar','BOL',75.5),('The Strongest','BOL',73.1),
 ('Deportivo Táchira','VEN',70.5),('Caracas FC','VEN',69.6)
]
clubs=[{'club':name,'country':'BRA','strength':float(club_overall[name]),'route':r['route'],'canonical':True} for r in conn.execute("select club,route from continental_qualifications where season=2027 and competition='Copa Libertadores' and status='clinched'") for name in [r['club']]]
clubs.extend({'club':n,'country':co,'strength':s,'route':'fictional non-Brazil qualifier','canonical':False} for n,co,s in others)
check(len(clubs)==32 and len({c['club'] for c in clubs})==32,'32 unique participants')
sula={r['club'] for r in conn.execute('select club from sudamericana_2027_groups')}
check(not (sula & {v['club'] for v in clubs}),str(sula & {v['club'] for v in clubs}))
check({v['club'] for v in clubs if v['country']=='BRA'}==set(bra),'Brazil participants mismatch')

# Ranking seeding 4 pots of 8 with stable randomized tiebreak; seed is set independent from results.
clubs.sort(key=lambda o:(-o['strength'],stable_seed('seed_tie:'+o['club'])))
for i,c in enumerate(clubs):c['pot']=1+i//8
print('POTS',json.dumps([[c['club'] for c in clubs if c['pot']==p] for p in range(1,5)],ensure_ascii=False))
# Need exactly one Brazilian pair (9 participants, 8 groups). Brazilian exceptions require Bragantino.
# Each other nationality at most once per group.
pool={p:[c for c in clubs if c['pot']==p] for p in range(1,5)}
group_letters='ABCDEFGH'
group_teams=None
for attempt in range(2000):
 d={g:[] for g in group_letters}
 rr=rng('draw_attempt_'+str(attempt))
 p1=pool[1][:];rr.shuffle(p1)
 for g,v in zip(group_letters,p1):d[g].append(v)
 possible=True
 for pot in (2,3,4):
  # Brazil placed ahead of non-Brazil; since last Brazilian is Bragantino, correct lone exception.
  pl=pool[pot][:];rr.shuffle(pl);pl.sort(key=lambda x:x['country']!='BRA')
  def insert(j):
   if j==len(pl):return True
   team=pl[j]
   avail=list(group_letters);rr.shuffle(avail)
   avail.sort(key=lambda k:len(d[k]))
   for g in avail:
    if len(d[g])!=pot-1:continue
    countries=[x['country'] for x in d[g]]
    if team['country'] in countries and not (team['club']=='Bragantino' and team['country']=='BRA' and countries.count('BRA')==1):continue
    if countries.count('BRA')>=2 and team['country']=='BRA':continue
    d[g].append(team)
    if insert(j+1):return True
    d[g].pop()
   return False
  if not insert(0):possible=False;break
 if possible and all(len(d[g])==4 for g in group_letters):
  check(sum(sum(c['country']=='BRA' for c in d[g])==2 for g in group_letters)==1,'need one BR double group')
  check(all(len({c['country'] for c in d[g]})==4 or sorted(c['country'] for c in d[g]).count('BRA')==2 for g in group_letters),'country repetition')
  group_teams=d;break
check(group_teams is not None,'No valid draw found')
print('DRAW',json.dumps({g:[v['club'] for v in vals] for g,vals in group_teams.items()},ensure_ascii=False))

# Complete group stage is generated as a retrospective fictional backfill (played in spring 2027).
cur.executescript('''
CREATE TABLE IF NOT EXISTS libertadores_2027_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS libertadores_2027_participants (club TEXT PRIMARY KEY, country TEXT NOT NULL, power REAL NOT NULL, pot INTEGER NOT NULL, qualification_route TEXT NOT NULL, canonical_brazil INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS libertadores_2027_groups (group_id TEXT NOT NULL, club TEXT NOT NULL UNIQUE, pot INTEGER NOT NULL, played INTEGER NOT NULL, wins INTEGER NOT NULL, draws INTEGER NOT NULL, losses INTEGER NOT NULL, gf INTEGER NOT NULL, ga INTEGER NOT NULL, points INTEGER NOT NULL, PRIMARY KEY(group_id,club));
CREATE TABLE IF NOT EXISTS libertadores_2027_fixtures (id INTEGER PRIMARY KEY, group_id TEXT NOT NULL, matchday INTEGER NOT NULL, dated TEXT NOT NULL, home TEXT NOT NULL, away TEXT NOT NULL, power_home REAL NOT NULL, power_away REAL NOT NULL, home_xg REAL NOT NULL, away_xg REAL NOT NULL, home_goals INTEGER NOT NULL, away_goals INTEGER NOT NULL, home_shots INTEGER NOT NULL, away_shots INTEGER NOT NULL, home_sot INTEGER NOT NULL, away_sot INTEGER NOT NULL, seed INTEGER NOT NULL, status TEXT NOT NULL, UNIQUE(group_id,matchday,home,away));
CREATE TABLE IF NOT EXISTS libertadores_2027_group_outcomes (group_id TEXT NOT NULL, rank INTEGER NOT NULL, club TEXT NOT NULL UNIQUE, played INTEGER NOT NULL, won INTEGER NOT NULL, drawn INTEGER NOT NULL, lost INTEGER NOT NULL, points INTEGER NOT NULL, gd INTEGER NOT NULL, gf INTEGER NOT NULL, ga INTEGER NOT NULL, route TEXT NOT NULL, PRIMARY KEY(group_id,rank));
CREATE TABLE IF NOT EXISTS libertadores_2027_round_of_16 (tie_id TEXT PRIMARY KEY, first_leg_home TEXT NOT NULL, second_leg_home TEXT NOT NULL, first_leg_date TEXT, second_leg_date TEXT, leg1_result TEXT, leg2_result TEXT, status TEXT NOT NULL, winner TEXT, first_seed_group TEXT NOT NULL, second_seed_group TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sudamericana_2027_playoffs (tie_id TEXT PRIMARY KEY, sula_runner_up TEXT NOT NULL, sula_group TEXT NOT NULL, lib_third TEXT NOT NULL, lib_group TEXT NOT NULL, first_leg_home TEXT NOT NULL, second_leg_home TEXT NOT NULL, first_leg_date TEXT, second_leg_date TEXT, status TEXT NOT NULL, winner TEXT);
CREATE TABLE IF NOT EXISTS libertadores_2027_club_form (club TEXT PRIMARY KEY, power_base REAL NOT NULL, group_points INTEGER NOT NULL, group_gd INTEGER NOT NULL, group_finish INTEGER NOT NULL, source TEXT NOT NULL);
''')
for c in clubs:cur.execute('insert into libertadores_2027_participants values(?,?,?,?,?,?)',(c['club'],c['country'],c['strength'],c['pot'],c['route'],int(c['canonical'])))
byname={c['club']:c for c in clubs}
stat={c['club']:dict(gp=0,w=0,d=0,l=0,gf=0,ga=0,pts=0) for c in clubs}
gdates=['2027-04-06','2027-04-13','2027-04-20','2027-05-04','2027-05-18','2027-05-25']
patterns=[[(0,3),(1,2)],[(2,0),(3,1)],[(0,1),(2,3)]]
for k in range(3):patterns.append([(b,a) for a,b in patterns[k]])
scaling_strength=7.5
matches=[]
for g in group_letters:
 names=[c['club'] for c in group_teams[g]]
 for md,pairs in enumerate(patterns,1):
  for idx,(hidx,aidx) in enumerate(pairs):
   h=names[hidx]; a=names[aidx]; r=rng(f'match:{g}:{md}:{h}:{a}')
   diff=byname[h]['strength']-byname[a]['strength']
   # Stochastic match xG, fixed state and home advantage; continent altitude explicit for Bolivia.
   altitude = (0.25 if h in ('Bolívar','The Strongest') else 0.0)
   # Strong clubs create a bit more; seed-dependent in-match randomness in xG estimates.
   hxg=round(max(.32,min(3.5,1.33+diff/scaling_strength*.32 + r.gauss(0,.22)+altitude)),2)
   axg=round(max(.29,min(3.5,1.07-diff/scaling_strength*.32 + r.gauss(0,.21)-altitude*.58)),2)
   hg=poisson(r,hxg);ag=poisson(r,axg)
   hs=max(hg,poisson(r,7.5+3.3*hxg));ats=max(ag,poisson(r,7.5+3.3*axg))
   hot=max(hg,min(hs,poisson(r,max(.3,hs*.33))));aot=max(ag,min(ats,poisson(r,max(.3,ats*.33))))
   seed=stable_seed(f'match:{g}:{md}:{h}:{a}') & ((1<<63)-1)
   row=dict(group=g,md=md,dated=gdates[md-1],home=h,away=a,hg=hg,ag=ag,hxg=hxg,axg=axg,hs=hs,ats=ats,hot=hot,aot=aot,seed=seed)
   matches.append(row)
   cur.execute('''insert into libertadores_2027_fixtures(group_id,matchday,dated,home,away,power_home,power_away,home_xg,away_xg,home_goals,away_goals,home_shots,away_shots,home_sot,away_sot,seed,status) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(g,md,row['dated'],h,a,byname[h]['strength'],byname[a]['strength'],hxg,axg,hg,ag,hs,ats,hot,aot,seed,'final'))
   stat[h]['gf']+=hg;stat[h]['ga']+=ag;stat[a]['gf']+=ag;stat[a]['ga']+=hg
   stat[h]['gp']+=1;stat[a]['gp']+=1
   if hg>ag:stat[h]['w']+=1;stat[a]['l']+=1;stat[h]['pts']+=3
   elif hg<ag:stat[a]['w']+=1;stat[h]['l']+=1;stat[a]['pts']+=3
   else:stat[h]['d']+=1;stat[a]['d']+=1;stat[h]['pts']+=1;stat[a]['pts']+=1
outcomes=[]
for g in group_letters:
 names=[c['club'] for c in group_teams[g]]
 rankings=sorted(names,key=lambda n:(-stat[n]['pts'],-(stat[n]['gf']-stat[n]['ga']),-stat[n]['gf'],-stat[n]['w'],n))
 for pos,n in enumerate(rankings,1):
  x=stat[n];route=['R16','R16','Sula playoff','Out'][pos-1]
  cur.execute('insert into libertadores_2027_groups values(?,?,?,?,?,?,?,?,?,?)',(g,n,byname[n]['pot'],x['gp'],x['w'],x['d'],x['l'],x['gf'],x['ga'],x['pts']))
  cur.execute('insert into libertadores_2027_group_outcomes values(?,?,?,?,?,?,?,?,?,?,?,?)',(g,pos,n,x['gp'],x['w'],x['d'],x['l'],x['pts'],x['gf']-x['ga'],x['gf'],x['ga'],route))
  cur.execute('insert into libertadores_2027_club_form values(?,?,?,?,?,?)',(n,byname[n]['strength'],x['pts'],x['gf']-x['ga'],pos,'retrospective team-level Libertadores-only group form; no existing player fitness changed'))
  outcomes.append(dict(group=g,rank=pos,club=n,**x,gd=x['gf']-x['ga'],route=route))

# Round of 16: random seeded draw of 8 group winners vs 8 runners-up, winners host return leg.
winners=[x for x in outcomes if x['rank']==1]; runners=[x for x in outcomes if x['rank']==2]
rr=rng('R16_draw_Aug_12_2027');rr.shuffle(winners);rr.shuffle(runners)
r16=[]
for i,(w,runner) in enumerate(zip(winners,runners),1):
 row=dict(tie=f'LIB-R16-{i:02d}',home1=runner['club'],home2=w['club'],winner_group=w['group'],runner_group=runner['group'],status='scheduled',dates=['2027-08-31','2027-09-07'])
 r16.append(row)
 cur.execute('insert into libertadores_2027_round_of_16 values(?,?,?,?,?,?,?,?,?,?,?)',(row['tie'],row['home1'],row['home2'],row['dates'][0],row['dates'][1],None,None,'scheduled',None,w['group'],runner['group']))

# Sula runner-ups meet Libertadores 3rds. Cross-rank 1-vs-8. High ranked Sula runner gets second leg at home.
sula2=[dict(r) for r in conn.execute("select group_id,club,points,gd,gf from sudamericana_2027_group_outcomes where position=2")]
sula2.sort(key=lambda x:(-x['points'],-x['gd'],-x['gf'],x['club']))
thirds=[x for x in outcomes if x['rank']==3]
thirds.sort(key=lambda x:(-x['pts'],-x['gd'],-x['gf'],x['club']))
playoffs=[]
for i,(s,t) in enumerate(zip(sula2,reversed(thirds)),1):
 row=dict(tie=f'SULA-PO-{i:02d}',sula=s['club'],sula_group=s['group_id'],lib=t['club'],lib_group=t['group'],status='scheduled')
 playoffs.append(row)
 cur.execute('insert into sudamericana_2027_playoffs values(?,?,?,?,?,?,?,?,?,?,?)',(row['tie'],s['club'],s['group_id'],t['club'],t['group'],t['club'],s['club'],'2027-08-26','2027-09-02','scheduled',None))

metadata={
 'type':'retrospective fictional group simulation, NOT observed reality',
 'season':'2027','version':'037L','parent_checkpoint':'037',
 'simulation_committed_on':'2027-08-12 (in-universe)',
 'rng_policy':'SHA-256 stable unique per fixture; one-pass no reroll',
 'origin_fixtures':'2027-04-06 through 2027-05-25 fictional retrospective backfill, dates chosen for continuity, historic other competitions immutable',
 'teams':'32 teams; 9 canonical Brazil qualifiers + 23 clearly fictional non-Brazil qualifiers',
 'group_draw':'4 strength-based pots, 8 groups; no repeated nation except single unavoidable Brazil double due to 9 Brazil qualifiers in 8 groups',
 'engine':'strength-weighted match xG with home advantage, conservative Bolivia elevation advantage and stochastic Poisson finishing; team-level proxies outside Brazilian league',
 'tiebreak':'points, goal difference, goals scored, wins, name as deterministic fallback (fictional rule)',
 'round16':'8 winners vs 8 runners drawn with fixed seed, group winners host second leg, no knockout results played',
 'sula_playoff':'8 Libertadores third-placed vs 8 existing Sula runners-up, 1st Sula runner vs 8th Lib 3rd etc; home return leg Sula',
 'schedule_caution':'R16 dates Aug 31/Sep 7 and Sula playoffs Aug 26/Sep 2 are provisional and can conflict with Brazilian fixtures; reconcile before advancing club matches',
 'impact_on_save':'read-only backfill for historical existing tables; new Libertadores + Sula playoff tables only; meta notes and news action; no Vasco match, money, player progression, standings or club fitness modified',
 'savarino_rule':'Fluminense #354 active, Botafogo #196 archived; unchanged',
}
for k,v in metadata.items():cur.execute('insert into libertadores_2027_meta values(?,?)',(k,str(v)))
cur.execute('insert or replace into meta(key,value) values(?,?)',('libertadores_2027_status','Group stage 96 of 96 matches completed and stored retrospectively; 8 R16 pairings scheduled but unplayed; 8 Libertadores-to-Sula playoff pairings scheduled but unplayed.'))
cur.execute('insert or replace into meta(key,value) values(?,?)',('libertadores_2027_checkpoint','037L'))
cur.execute('insert or replace into meta(key,value) values(?,?)',('saved_state_version','037L'))
cur.execute('insert into continental_calendar_actions(dated,action,notes) values(?,?,?)',('2027-08-12','Retrospective Libertadores 2027 group stage simulation + R16 draw','32 qualified; 96 games one-time simulated, historical window Apr-May. Existing Brasileirao/Sula/Copa results, Vasco squad and finances untouched. Foreign club team-level profiles. 8 Sula playoff pairings linked; provisional dates must be reconciled.'))
conn.commit()

# QA with database invariants. source previous table contents must be byte-for-byte logically identical.
for t in ['clubs','players','fixtures','events','shots','player_matches','finance_ledger','sudamericana_2027_fixtures','sudamericana_2027_groups','sudamericana_2027_group_outcomes','cdb_2027_bracket','cdb_2027_legs','player_form_snapshot','match_form_profile','player_identity_resolution']:
 old=sqlite3.connect(src)
 prev=[tuple(row) for row in old.execute('select * from '+t+' order by rowid')]; now=[tuple(row) for row in conn.execute('select * from '+t+' order by rowid')]
 old.close();check(prev==now,'HISTORY MUTATED '+t)
check(len(matches)==96,'96 games')
check(all(s['gp']==6 for s in stat.values()),'each club 6 games')
check(all( (s['w']*3+s['d'])==s['pts'] for s in stat.values()),'points invariant')
check(sum(x['gf'] for x in stat.values())==sum(x['ga'] for x in stat.values()),'goal totals')
check(sum(x['pts'] for x in stat.values())==3*sum(m['hg']!=m['ag'] for m in matches)+2*sum(m['hg']==m['ag'] for m in matches),'total points')
check(len(r16)==8 and len({r['home2'] for r in r16})==8 and len({r['home1'] for r in r16})==8,'R16 draw')
check(len(playoffs)==8 and len({r['lib'] for r in playoffs})==8 and len({r['sula'] for r in playoffs})==8,'Sula playoffs')
check(sum(x['rank']==1 for x in outcomes)==8 and sum(x['rank']==2 for x in outcomes)==8 and sum(x['rank']==3 for x in outcomes)==8,'group rank')
check(conn.execute('pragma integrity_check').fetchone()[0]=='ok','SQLite integrity')
# Verify fixture home-away pair exact once
for g in group_letters:
 club_names=[c['club'] for c in group_teams[g]]
 for x in club_names:
  check(sum(1 for m in matches if m['group']==g and m['home']==x)==3,'3 home')
  check(sum(1 for m in matches if m['group']==g and m['away']==x)==3,'3 away')
print('QA_OK: 96 fixtures, 32 clubs 6 matches each, 8R16 and 8SulaPO, source historical rows invariant')

v={'checkpoint':'037L','seed_policy':metadata['rng_policy'],'sources':'Save037 canonical qualification and 2026 final, 2026 Libertadores rules for structure, fiction non-Brazil club pool',
   'teams':clubs,'groups':{g:[c['club'] for c in group_teams[g]] for g in group_letters},'outcomes':outcomes,'matches':matches,'r16':r16,'sula_playoffs':playoffs,'metadata':metadata,
 'highlights':sorted(matches,key=lambda m:(m['hg']+m['ag'],m['group']),reverse=True)[:12],
 'checks':{'source_historical_tables_unchanged':True,'all_clubs_six_matches':True,'all_96_fixtures_completed':True,'one_double_brazil_group':True,'no_sula_participants_in_libertadores':True}}
(out/'libertadores_2027_results.json').write_text(json.dumps(v,ensure_ascii=False,indent=2))
conn.close()
print('R16',json.dumps(r16,ensure_ascii=False))
print('SULA PO',json.dumps(playoffs,ensure_ascii=False))
print('RESULTS_JSON',out/'libertadores_2027_results.json')
