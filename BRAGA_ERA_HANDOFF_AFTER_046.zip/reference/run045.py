from pathlib import Path
import sqlite3,random,math,json,shutil,hashlib,zipfile,collections
B=Path('/mnt/data/Braga_Era');P=B/'work045';P.mkdir(exist_ok=True)
D=P/'braga_save.sqlite'
shutil.copy2(B/'work044T'/'braga_save.sqlite',D)
c=sqlite3.connect(D);c.row_factory=sqlite3.Row
old={r['id']:tuple(r) for r in c.execute("select * from fixtures where status='final'")};ledger=[tuple(r) for r in c.execute('select * from finance_ledger')];trans=[tuple(r) for r in c.execute('select * from transfers')]
assert c.execute("select value from meta where key='saved_state_version'").fetchone()[0]=='044T'
ref=(B/'tmp036'/'Save036'/'engine_2027_reference.py').read_text();exec(ref[ref.index('def rng_for('):ref.index('# Four promoted clubs')]);core=ref[ref.index('def pick('):ref.index('# record Jan/Feb')]
formmap={r['player_id']:r['form_rating'] for r in c.execute('select * from match_form_profile')}
core=core.replace("p['ovr']+.05*p['fitness']+.01*p['morale']", "p['ovr']+.05*p['fitness']+.01*p['morale']+2.1*(formmap.get(p['id'],6.55)-6.55)")
core=core.replace("for p in sorted(ps,key=lambda p:p['ovr'],reverse=True):","for p in sorted(ps,key=lambda p:p['ovr']+2.1*(formmap.get(p['id'],6.55)-6.55),reverse=True):")
core=core.replace("+.22*team['form']+.02*", "+.42*team['form']+.45*(sum(formmap.get(p['id'],6.55)-6.55 for p in xi)/11)+.02*")
core=core.replace("goal=int(rng.random()<xg)","goal=0")
core=core.replace("new=sorted(incoming,key=lambda p:p['ovr']+.03*p['fitness'],reverse=True)[0]", "new=sorted(incoming,key=lambda p:p['ovr']+.03*p['fitness']+2*(formmap.get(p['id'],6.55)-6.55),reverse=True)[0]")
core=core.replace("outgoing=[x for x in active[club] if x['pos']==pos and x['pos']!='GK']", "outgoing=[x for x in active[club] if x['pos']==pos and x['pos']!='GK' and particip[x['id']]['starter']==1]")
core=core.replace("goal=event['goal']","goal=int(rng.random()<clamp(xg*(1+.25*(formmap.get(p['id'],6.55)-6.55)),.006,.82))")
core=core.replace("r=round(clamp(6.45+(p['ovr']-72)*.033","r=round(clamp(6.45+.18*(formmap.get(pid,6.55)-6.55)+(p['ovr']-72)*.033")
# Braga retains balanced 4-2-3-1 and considers Carlos Vinicius after recent assist. No score interventions.
core=core.replace("vasco_pref=['Léo Jardim','Paulo Henrique','Gustavo Martins','Robert Renan','Lucas Piton','Santiago Sosa','Rodrigo Villagra','Alan Lescano','Andrés Gómez','Facundo Colidio','Carlos Vinícius']", "vasco_pref=['Léo Jardim','Paulo Henrique','Cuiabano','Santiago Sosa','Rodrigo Villagra','Alan Lescano','Andrés Gómez','Facundo Colidio','Bruno Duarte']")
vasco_pref=['Léo Jardim','Paulo Henrique','Cuiabano','Santiago Sosa','Rodrigo Villagra','Alan Lescano','Andrés Gómez','Facundo Colidio','Bruno Duarte']
exec(core)
fixtures=[dict(r) for r in c.execute('''select f.id,f.round,h.name home,a.name away from fixtures f join clubs h on h.id=f.home_id join clubs a on a.id=f.away_id where f.competition='Brasileirão 2027' and f.round='R24' order by f.id''')]
assert len(fixtures)==10 and any(z['home']=='Santos' and z['away']=='Vasco' for z in fixtures)
assert all(f['id'] for f in fixtures)
c.execute('update players set fitness=min(100,fitness+6) where club_id in (select club_id from league_participants where season=2027)')
c.execute("update players set injury='' where injury='minor muscle strain (5 days)'")
c.execute('insert into decisions(dated,category,decision,impact) values(?,?,?,?)',('2027-09-19','tactical meeting','Braga visits Santos after six-day defensive shape/chemistry microcycle; autonomous lineup.','Form and physical condition drive squad choices; no predetermined outcome.'))
# Seven-day defensive training, logged before kick-off; modest deterministic defensive adjustment, not conditional on score.
c.execute('insert into decisions(dated,category,decision,impact) values(?,?,?,?)',('2027-09-18','training','Defensive chemistry microcycle completed 13–18 September; measured defensive coaching adjustment, modest and not outcome-guaranteeing.','Chemistry gain equivalent to +0.50 effective match strength (reversible); no guaranteed clean sheet; track GA/xGA.'))
# Existing simulator team form affects match quality: training affects Vasco team strength temporarily, without rating inflation.
c.execute("update clubs set strength=strength+0.50 where name='Vasco'")
c.execute("update training_microcycles_2027 set effect_status='completed before kickoff; tactical effect tested in R24' where club='Vasco' and end_date<='2027-09-18'")
c.execute("insert or replace into meta values('defensive_chemistry_2027_09_19','0.50 transient effective match strength from completed 6-day training, reverted immediately after simulated fixture; monitor xGA and early chances on later rounds')")
# Detailed audit for all games, using original probabilistic shot stream plus prior form adjustment.
def formcalc(pid):
 rows=list(c.execute('''select pm.rating,pm.minutes from player_matches pm join fixtures f on f.id=pm.fixture_id where pm.player_id=? and f.competition='Brasileirão 2027' order by f.datetime_local desc,f.id desc limit 4''',(pid,)))
 if not rows:return 6.55
 w=[.68**i*min(1,r['minutes']/60)**.5 for i,r in enumerate(rows)];return round(6.55+(sum(x*r['rating'] for x,r in zip(w,rows))/sum(w)-6.55)*min(1,len(rows)/3),3)
results=[]
for f in fixtures:
 before={r['id']:formcalc(r['id']) for r in c.execute('select id from players')}
 res=simulate(f['id']);results.append(res)
 for r in c.execute('select player_id,minutes from player_matches where fixture_id=?',(f['id'],)).fetchall():
  pid=r['player_id'];after=formcalc(pid)
  c.execute('insert or replace into player_form_snapshot values(?,?,?,?,?,?,?)',(f['id'],pid,before[pid],after,before[pid],after,r['minutes']))
  c.execute('insert or replace into match_form_profile values(?,?,?)',(pid,after,'2027-09-19'))
  formmap[pid]=after
 c.execute('insert into match_engine_audit values(?,?,?,?,?,?,?)',(f['id'],'league_v3_R24_chemistry_measured',0,0,0,0,'Seeded probabilities; rolling form affecting XI, shooter outcomes, effective team strength; one execution no rerolls'))
c.execute("update clubs set strength=strength-0.50 where name='Vasco'")
for k,v in [('saved_state_version','045'),('current_date','2027-09-19 23:30'),('next_match_fixture','Brasileirão R25 - consult scheduled fixtures'),('2027_brasileirao_status','Rounds 01-24 complete: 240 matches; 140 scheduled')]:c.execute('insert or replace into meta values(?,?)',(k,v))
c.execute('insert or replace into meta values(?,?)',('player_identity_audit_045','Savarino canonical Fluminense #354; Botafogo #196 archived, ineligible; history intact'))
c.commit()
assert c.execute('pragma integrity_check').fetchone()[0]=='ok'; assert c.execute('select count(*) from libertadores_2027_fixtures').fetchone()[0]==96; assert c.execute('select count(*) from libertadores_2027_round_of_16').fetchone()[0]==8; assert c.execute('select count(*) from sudamericana_2027_playoffs').fetchone()[0]==8
assert all(tuple(c.execute('select * from fixtures where id=?',(k,)).fetchone())==v for k,v in old.items())
assert [tuple(r) for r in c.execute('select * from finance_ledger')]==ledger and [tuple(r) for r in c.execute('select * from transfers')]==trans
assert c.execute("select count(*) from fixtures where competition='Brasileirão 2027' and status='final'").fetchone()[0]==240
for f in fixtures:
 row=c.execute('select * from fixtures where id=?',(f['id'],)).fetchone();n=row['home_goals']+row['away_goals']
 assert n==c.execute("select count(*) from events where fixture_id=? and event_type='GOAL'",(f['id'],)).fetchone()[0]==c.execute('select sum(goal) from shots where fixture_id=?',(f['id'],)).fetchone()[0]
stand=[dict(r) for r in c.execute('''select cl.name club,cl.played,cl.wins w,cl.draws d,cl.losses l,cl.gf,cl.ga,cl.points pts,cl.gf-cl.ga gd from clubs cl join league_participants lp on lp.club_id=cl.id where lp.season=2027 order by pts desc,w desc,gd desc,gf desc,club''')]
assert len(stand)==20 and all(z['played']==24 for z in stand)
v=next(z for z in results if 'Vasco' in (z['home'],z['away']))
players=[dict(r) for r in c.execute('''select p.name,p.pos,p.ovr,pm.minutes,pm.starter,pm.goals,pm.assists,pm.shots,pm.rating,pm.xg,s.form_before,s.form_after from player_matches pm join players p on p.id=pm.player_id join player_form_snapshot s on s.player_id=p.id and s.fixture_id=pm.fixture_id where pm.fixture_id=? and pm.club_id=(select id from clubs where name='Vasco') order by pm.rating desc''',(v['id'],))]
nextfix=[dict(r) for r in c.execute('''select f.round,f.datetime_local,h.name home,a.name away from fixtures f join clubs h on h.id=f.home_id join clubs a on a.id=f.away_id where f.round='R25' and f.competition='Brasileirão 2027' ''')]
state={'results':results,'vasco':v,'vasco_players':players,'standings':stand,'board':int(c.execute("select value from meta where key='board_confidence'").fetchone()[0]),'cash':sum(row['amount_brl'] for row in c.execute("select amount_brl from finance_ledger where account='2027 football restricted account'")),'next':nextfix,'manager_matches':int(c.execute("select value from meta where key='braga_matches'").fetchone()[0]),'preexisting_count':len(old)}
(P/'results045.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
print(json.dumps({'match':v,'standings':[(z['club'],z['pts'],z['gd']) for z in stand],'results':[(z['home'],z['hg'],z['ag'],z['away']) for z in results],'board':state['board'],'next':next(z for z in nextfix if 'Vasco' in (z['home'],z['away']))},ensure_ascii=False,indent=2))
c.close()
