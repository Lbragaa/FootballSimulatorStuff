"""THE BRAGA ERA 046: R25 one deterministic pass from canonical Save045.
Outcome-agnostic defensive coaching effect fixed before kickoff, no rerolls.
"""
from pathlib import Path
import sqlite3,random,math,json,shutil,hashlib,collections
B=Path('/mnt/data/Braga_Era');P=B/'work046';P.mkdir(exist_ok=True)
D=P/'braga_save.sqlite'; SRC=B/'work045'/'braga_save.sqlite'
assert SRC.exists()
shutil.copy2(SRC,D)
c=sqlite3.connect(D);c.row_factory=sqlite3.Row
assert c.execute("select value from meta where key='saved_state_version'").fetchone()[0]=='045'
old={r['id']:tuple(r) for r in c.execute("select * from fixtures where status='final'")}
ledger=[tuple(r) for r in c.execute('select * from finance_ledger')]
trans=[tuple(r) for r in c.execute('select * from transfers')]
oldplayerlist=[tuple(r) for r in c.execute('select id,club_id,name,ovr from players')]
continental={t:[tuple(r) for r in c.execute('select * from '+t)] for t in ['libertadores_2027_fixtures','libertadores_2027_round_of_16','sudamericana_2027_fixtures','sudamericana_2027_playoffs','cdb_2027_bracket','cdb_2027_legs']}
ref=(B/'tmp036'/'Save036'/'engine_2027_reference.py').read_text(encoding='utf-8')
exec(ref[ref.index('def rng_for('):ref.index('# Four promoted clubs')])
core=ref[ref.index('def pick('):ref.index('# record Jan/Feb')]
formmap={r['player_id']:r['form_rating'] for r in c.execute('select * from match_form_profile')}
core=core.replace("p['ovr']+.05*p['fitness']+.01*p['morale']","p['ovr']+.05*p['fitness']+.01*p['morale']+2.1*(formmap.get(p['id'],6.55)-6.55)")
core=core.replace("for p in sorted(ps,key=lambda p:p['ovr'],reverse=True):","for p in sorted(ps,key=lambda p:p['ovr']+2.1*(formmap.get(p['id'],6.55)-6.55),reverse=True):")
core=core.replace("+.22*team['form']+.02*","+.42*team['form']+.45*(sum(formmap.get(p['id'],6.55)-6.55 for p in xi)/11)+.02*")
core=core.replace("goal=int(rng.random()<xg)","goal=0")
core=core.replace("new=sorted(incoming,key=lambda p:p['ovr']+.03*p['fitness'],reverse=True)[0]","new=sorted(incoming,key=lambda p:p['ovr']+.03*p['fitness']+2*(formmap.get(p['id'],6.55)-6.55),reverse=True)[0]")
core=core.replace("outgoing=[x for x in active[club] if x['pos']==pos and x['pos']!='GK']","outgoing=[x for x in active[club] if x['pos']==pos and x['pos']!='GK' and particip[x['id']]['starter']==1]")
core=core.replace("goal=event['goal']","goal=int(rng.random()<clamp(xg*(1+.25*(formmap.get(p['id'],6.55)-6.55)),.006,.82))")
core=core.replace("r=round(clamp(6.45+(p['ovr']-72)*.033","r=round(clamp(6.45+.18*(formmap.get(pid,6.55)-6.55)+(p['ovr']-72)*.033")
# discard invalid yellow card timestamps after substitutions, no rewrite of outcomes
core=core.replace("elif typ=='YELLOW':ev.append((minute,club,event['player_id'],'YELLOW',0,''))", "elif typ=='YELLOW':\n   if any(p['id']==event['player_id'] for p in active[club]):ev.append((minute,club,event['player_id'],'YELLOW',0,''))")
# Player-coach integration: continued training reduces OPPONENT expected xG by only 0.06,
# precommitted regardless of whether Vasco wins or concedes. Only affects R25, not OVR.
oldline="if h['name']=='Vasco':hx_base+=.08;ax_base+=.04"
assert oldline in core
core=core.replace(oldline,oldline+"\n if h['name']=='Vasco':ax_base=max(.38,ax_base-.06)\n if a['name']=='Vasco':hx_base=max(.45,hx_base-.06)")

core=core.replace("vasco_pref=['Léo Jardim','Paulo Henrique','Gustavo Martins','Robert Renan','Lucas Piton','Santiago Sosa','Rodrigo Villagra','Alan Lescano','Andrés Gómez','Facundo Colidio','Carlos Vinícius']", "vasco_pref=['Léo Jardim','Paulo Henrique','Cuiabano','Santiago Sosa','Rodrigo Villagra','Alan Lescano','Andrés Gómez','Facundo Colidio','Bruno Duarte']")
vasco_pref=['Léo Jardim','Paulo Henrique','Cuiabano','Santiago Sosa','Rodrigo Villagra','Alan Lescano','Andrés Gómez','Facundo Colidio','Bruno Duarte']
exec(core)
fixtures=[dict(r) for r in c.execute('''select f.id,f.round,f.datetime_local,h.name home,a.name away from fixtures f join clubs h on h.id=f.home_id join clubs a on a.id=f.away_id where f.competition='Brasileirão 2027' and f.round='R25' order by f.id''')]
assert len(fixtures)==10 and len({t['home'] for t in fixtures}|{t['away'] for t in fixtures})==20
assert next(f for f in fixtures if f['home']=='Vasco')['away']=='Palmeiras'
assert all(c.execute('select status from fixtures where id=?',(f['id'],)).fetchone()[0]=='scheduled' for f in fixtures)
# One-week recovery; continuity work logged before any random kickoff.
c.execute("update players set fitness=min(100,fitness+6) where club_id in (select club_id from league_participants where season=2027)")
c.execute("update players set injury='' where injury='minor muscle strain (5 days)'")
c.execute('insert into decisions(dated,category,decision,impact) values(?,?,?,?)',('2027-09-20','training','Braga maintains defensive communication and positional compactness microcycle for Palmeiras week, balances load/recovery and takes previous clean sheet as positive but not proof.','Outcome-blind -0.06 Palmeiras prematch expected xG vs Vasco; no guarantee on goals, no rating inflation.'))
c.execute('insert into decisions(dated,category,decision,impact) values(?,?,?,?)',('2027-09-25','tactical meeting','Autonomous Braga lineup for Palmeiras; Gómez high form, Bruno Duarte remains key provider and goalscorer, Carlos Vinícius/Barreal bench options.','No mandated XI spots for new signings; live score-aware substitutions only.'))
c.execute('insert into training_microcycles_2027(start_date,end_date,club,focus,workload,content,target_metric,effect_status,coach_note) values (?,?,?,?,?,?,?,?,?)',('2027-09-20','2027-09-25','Vasco','defensive chemistry and resistance vs title contender','moderate','Back four/volante distances; counter-press timings; keeper-led defensive commands; video on defending leads; final day light recovery','GA, xGA, early GA, clean sheets over R25–R29','completed before R25','precommitted marginal -0.06 opposition expected xG for R25 only; no score manipulation'))
c.execute('insert or replace into meta values (?,?)',('defensive_chemistry_2027_09_26','R24 microcycle accumulated: R25 precommitted -0.06 opposition prematch xG only; subsequent rounds require new measured training; underlying OVR unchanged'))
def formcalc(pid):
 rows=list(c.execute('''select pm.rating,pm.minutes from player_matches pm join fixtures f on f.id=pm.fixture_id where pm.player_id=? and f.competition='Brasileirão 2027' order by f.datetime_local desc,f.id desc limit 4''',(pid,)))
 if not rows:return 6.55
 w=[.68**i*min(1,r['minutes']/60)**.5 for i,r in enumerate(rows)]
 return round(6.55+(sum(x*r['rating'] for x,r in zip(w,rows))/sum(w)-6.55)*min(1,len(rows)/3),3)
results=[]
for f in fixtures:
 before={r['id']:formcalc(r['id']) for r in c.execute('select id from players')}
 res=simulate(f['id']);results.append(res)
 for r in c.execute('select player_id,minutes from player_matches where fixture_id=?',(f['id'],)).fetchall():
  pid=r['player_id'];after=formcalc(pid)
  c.execute('insert or replace into player_form_snapshot values(?,?,?,?,?,?,?)',(f['id'],pid,before[pid],after,before[pid],after,r['minutes']))
  c.execute('insert or replace into match_form_profile values(?,?,?)',(pid,after,'2027-09-26'))
  formmap[pid]=after
 c.execute('insert into match_engine_audit values(?,?,?,?,?,?,?)',(f['id'],'league_v3_R25_chemistry_continuity',0,0,0,0,'Single deterministic seeded draw; rolling individual form + voluntary Bruno/Carlos usage; -0.06 Vasco opposition prematch xG from defensive drills outcome-blind.'))
for k,v in [('saved_state_version','046'),('current_date','2027-09-26 23:30'),('next_match_fixture','2027-10-03 Mirassol vs Vasco, Brasileirão R26'),('2027_brasileirao_status','Rounds 01-25 complete: 250 matches; 130 scheduled')]:
 c.execute('insert or replace into meta values(?,?)',(k,v))
c.commit()
assert c.execute('pragma integrity_check').fetchone()[0]=='ok'
assert c.execute("select count(*) from fixtures where competition='Brasileirão 2027' and status='final'").fetchone()[0]==250
assert c.execute("select count(*) from fixtures where competition='Brasileirão 2027' and status='scheduled'").fetchone()[0]==130
assert all(tuple(c.execute('select * from fixtures where id=?',(id_,)).fetchone())==r for id_,r in old.items())
assert [tuple(r) for r in c.execute('select * from finance_ledger')]==ledger
assert [tuple(r) for r in c.execute('select * from transfers')]==trans
assert [tuple(r) for r in c.execute('select id,club_id,name,ovr from players')]==oldplayerlist
for t,rows in continental.items():assert [tuple(r) for r in c.execute('select * from '+t)]==rows,t
for f in fixtures:
 fix=c.execute('select * from fixtures where id=?',(f['id'],)).fetchone();fid=f['id']; ng=fix['home_goals']+fix['away_goals']
 assert c.execute('select count(*) from events where fixture_id=? and event_type="GOAL"',(fid,)).fetchone()[0]==ng
 assert c.execute('select coalesce(sum(goal),0) from shots where fixture_id=?',(fid,)).fetchone()[0]==ng
 assert c.execute('select coalesce(sum(goals),0) from player_matches where fixture_id=?',(fid,)).fetchone()[0]==ng
 assert c.execute('select count(*) from player_matches where fixture_id=? and starter=1',(fid,)).fetchone()[0]==22
 for tid,xg,sh,sot in [(fix['home_id'],fix['home_xg'],fix['home_shots'],fix['home_sot']),(fix['away_id'],fix['away_xg'],fix['away_shots'],fix['away_sot'])]:
  rx=c.execute('select coalesce(sum(xg),0),count(*),coalesce(sum(on_target),0) from shots where fixture_id=? and club_id=?',(fid,tid)).fetchone()
  assert round(rx[0],2)==xg and rx[1]==sh and rx[2]==sot,(fid,tid,rx,xg,sh,sot)
 for e in c.execute("select e.minute,e.player_id,e.club_id from events e where e.fixture_id=? and e.event_type='YELLOW'",(fid,)):
  pm=c.execute('select starter,minutes from player_matches where fixture_id=? and player_id=?',(fid,e['player_id'])).fetchone()
  assert pm and (pm['starter']==1 and pm['minutes']>=e['minute'] or pm['starter']==0 and 90-pm['minutes']<=e['minute']),(fid,dict(e))
# table independently re-derive from all played fixtures
stand=[dict(r) for r in c.execute('''select cl.name club,cl.played,cl.wins w,cl.draws d,cl.losses l,cl.gf,cl.ga,cl.points pts,cl.gf-cl.ga gd from clubs cl join league_participants lp on lp.club_id=cl.id where lp.season=2027 order by pts desc,w desc,gd desc,gf desc,club''')]
assert len(stand)==20 and all(x['played']==25 for x in stand)
for r in stand:
 tid=c.execute('select id from clubs where name=?',(r['club'],)).fetchone()[0]
 rows=list(c.execute("select * from fixtures where competition='Brasileirão 2027' and status='final' and (home_id=? or away_id=?)",(tid,tid)))
 assert len(rows)==r['played']==25
 won=lost=drew=gf=ga=0
 for f in rows:
  h=(tid==f['home_id']); g=f['home_goals'] if h else f['away_goals'];other=f['away_goals'] if h else f['home_goals'];gf+=g;ga+=other;won+=(g>other);drew+=(g==other);lost+=(g<other)
 assert (won,lost,drew,gf,ga,3*won+drew)==(r['w'],r['l'],r['d'],r['gf'],r['ga'],r['pts']),r['club']
vasco=next(z for z in results if z['home']=='Vasco')
v_id=c.execute("select id from clubs where name='Vasco'").fetchone()[0]
players=[dict(r) for r in c.execute('''select p.id,p.name,p.pos,p.ovr,pm.minutes,pm.starter,pm.goals,pm.assists,pm.shots,pm.rating,pm.xg,s.form_before,s.form_after from player_matches pm join players p on p.id=pm.player_id join player_form_snapshot s on s.player_id=p.id and s.fixture_id=pm.fixture_id where pm.fixture_id=? and pm.club_id=? order by pm.rating desc,pm.minutes desc''',(vasco['id'],v_id))]
xi=[r for r in players if r['starter']==1]
nextf=[dict(r) for r in c.execute('''select f.round,f.datetime_local,h.name home,a.name away from fixtures f join clubs h on h.id=f.home_id join clubs a on a.id=f.away_id where f.round='R26' and f.competition='Brasileirão 2027' order by f.datetime_local,f.id''')]
# Last five Vasco for trend
vlast=[]
for r in c.execute('''select f.round,f.datetime_local,h.name home,a.name away,f.home_goals hg,f.away_goals ag,f.home_xg hxg,f.away_xg axg from fixtures f join clubs h on h.id=f.home_id join clubs a on a.id=f.away_id where f.competition='Brasileirão 2027' and f.status='final' and (h.name='Vasco' or a.name='Vasco') order by f.datetime_local desc,f.id desc limit 6'''):
 v=dict(r);v['ga']=v['ag'] if v['home']=='Vasco' else v['hg'];v['xga']=v['axg'] if v['home']=='Vasco' else v['hxg'];v['gf']=v['hg'] if v['home']=='Vasco' else v['ag'];vlast.append(v)
state={'results':results,'vasco':vasco,'vasco_players':players,'vasco_xi':xi,'standings':stand,'board':int(c.execute("select value from meta where key='board_confidence'").fetchone()[0]),'cash':sum(r['amount_brl'] for r in c.execute("select amount_brl from finance_ledger where account='2027 football restricted account'")),'next':nextf,'manager_matches':int(c.execute("select value from meta where key='braga_matches'").fetchone()[0]),'vasco_last6':vlast,'preexisting_count':len(old),'defense_effect':'-.06 Palmeiras base xG from continued training; applied before match, no score intervention'}
(P/'results046.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
(P/'SAVE_BIBLE_046.md').write_text('# Canonical Save 046\nBraga Era R25, Sep 26 2027. Generated ONCE from Save045 SQLite.\n250/380 matches final, 130 scheduled. KO brackets, all previous fixtures, transfer contracts, continental results and finance ledger verified unchanged. Pre-game defender chemistry only affects Palmeiras expected chance quality by -0.06 xG, not OVR or score deterministically.\n',encoding='utf-8')
print(json.dumps({'match':vasco,'xi':[r['name'] for r in xi],'subs':vasco['subs'],'others':[(r['home'],r['hg'],r['ag'],r['away']) for r in results if r['id']!=vasco['id']],'table':[(i+1,r['club'],r['pts'],r['gd']) for i,r in enumerate(stand)],'board':state['board'],'cash':state['cash'],'manager':state['manager_matches'],'next':next(r for r in nextf if 'Vasco' in (r['home'],r['away']))},ensure_ascii=False,indent=2))
c.close()
