#!/usr/bin/env python3
"""Offline handoff verification (read-only). Invoke from anywhere: python path/to/tools/verify_handoff.py"""
import sqlite3, pathlib, json, hashlib, sys, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
P=ROOT/'canonical/braga_save.sqlite';R=ROOT/'canonical/results046.json';Z=ROOT/'canonical/Braga_Era_SAVE_046_ORIGINAL.zip'
assert all(x.exists() for x in (P,R,Z)), 'Missing required canonical file'
c=sqlite3.connect(f'file:{P}?mode=ro',uri=True);c.row_factory=sqlite3.Row
assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
m={r['key']:r['value'] for r in c.execute('select * from meta')}
assert m['saved_state_version']=='046'
assert m['next_match_fixture'].startswith('2027-10-03 Mirassol vs Vasco')
assert c.execute("select count(*) from fixtures where competition='Brasileirão 2027' and status='final'").fetchone()[0]==250
assert c.execute("select count(*) from fixtures where competition='Brasileirão 2027' and status='scheduled'").fetchone()[0]==130
assert c.execute('select count(*) from libertadores_2027_fixtures').fetchone()[0]==96
assert c.execute('select count(*) from sudamericana_2027_fixtures').fetchone()[0]==96
assert c.execute('select count(*) from cdb_2027_legs').fetchone()[0]==48
fx=c.execute("select f.*,h.name home,a.name away from fixtures f join clubs h on f.home_id=h.id join clubs a on f.away_id=a.id where f.competition='Brasileirão 2027' and f.round='R25' and h.name='Vasco'").fetchone()
assert fx['away']=='Palmeiras' and (fx['home_goals'],fx['away_goals'])==(3,2)
assert c.execute("select count(*) from fixtures where competition='Brasileirão 2027' and round='R25' and status='final'").fetchone()[0]==10
V=c.execute("select points,played,wins,draws,losses,gf,ga from clubs where name='Vasco'").fetchone()
assert tuple(V)==(38,25,11,5,9,36,37)
assert m['board_confidence']=='61'
assert c.execute('select count(*) from players').fetchone()[0]==547
assert c.execute('select count(*) from transfers').fetchone()[0]==9
assert all(c.execute('select status from libertadores_2027_round_of_16').fetchone())
assert json.loads(R.read_text(encoding='utf-8'))['vasco']['hg']==3
assert zipfile.ZipFile(Z).testzip() is None
with zipfile.ZipFile(Z) as rawzip:
 assert hashlib.sha256(rawzip.read('Save046/braga_save.sqlite')).digest()==hashlib.sha256(P.read_bytes()).digest(), 'Canonical database differs from original Save046 ZIP'
# Full Serie A 2027 inventory: 25 completed ten-game rounds, no duplicates, correct standings.
for n in range(1,39):
 matches=list(c.execute("""select f.*,h.name hname,a.name aname from fixtures f join clubs h on h.id=f.home_id join clubs a on a.id=f.away_id where f.competition='Brasileirão 2027' and f.round=?""", (f'R{n:02}',)))
 assert len(matches)==10, (n,'missing fixture')
 assert len(set([m['home_id'] for m in matches]+[m['away_id'] for m in matches]))==20,(n,'club duplicated')
 assert all(m['status']==('final' if n<=25 else 'scheduled') for m in matches),(n,'status invalid')
for team in c.execute("select cl.* from clubs cl join league_participants lp on lp.club_id=cl.id and lp.season=2027"):
 tid=team['id'];w=d=l=gf=ga=0
 for f in c.execute("select * from fixtures where competition='Brasileirão 2027' and status='final' and (home_id=? or away_id=?)",(tid,tid)):
  scored=f['home_goals'] if f['home_id']==tid else f['away_goals']
  conceded=f['away_goals'] if f['home_id']==tid else f['home_goals']
  gf+=scored;ga+=conceded
  if scored>conceded:w+=1
  elif scored==conceded:d+=1
  else:l+=1
 assert (team['played'],team['wins'],team['draws'],team['losses'],team['gf'],team['ga'],team['points'])==(25,w,d,l,gf,ga,3*w+d),team['name']
for fix in c.execute("select * from fixtures where competition='Brasileirão 2027' and round='R25'"):
 fid=fix['id'];goals=fix['home_goals']+fix['away_goals']
 assert c.execute("select count(*) from events where fixture_id=? and event_type='GOAL'",(fid,)).fetchone()[0]==goals
 assert c.execute("select sum(goal) from shots where fixture_id=?",(fid,)).fetchone()[0]==goals
 assert c.execute("select count(*) from player_matches where fixture_id=? and starter=1",(fid,)).fetchone()[0]==22
assert c.execute("select count(*) from cdb_2027_bracket where stage='Oitavas' and status='complete'").fetchone()[0]==8
assert c.execute("select count(*) from cdb_2027_bracket where stage='Quartas' and status='scheduled'").fetchone()[0]==4
assert c.execute("select count(*) from libertadores_2027_round_of_16 where status='scheduled'").fetchone()[0]==8
assert c.execute("select count(*) from sudamericana_2027_playoffs where status='scheduled'").fetchone()[0]==8
cash=c.execute("select sum(amount_brl) from finance_ledger where account='2027 football restricted account'").fetchone()[0]
assert cash==31930000, ('restricted cash mismatch',cash)
manifest=ROOT/'MANIFEST_SHA256.txt' 
if manifest.exists():
 for ln in manifest.read_text().splitlines():
  if not ln.strip():continue
  sha,path=ln.split('  ',1);path=ROOT/path
  assert path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==sha,path
print('PASS — canonical Save046 verified')
print('DATE',m['current_date'],'NEXT',m['next_match_fixture'])
print('VASCO 3–2 PALMEIRAS | 250 final + 130 scheduled | 96 Libertadores groups | 96 Sula groups | 48 Copa games')
print('NOTE: cup knockout dates are overdue and must be administratively reconciled before further gameplay.')
